﻿#include "common.h"
#include "functions.h"
#include <iostream>
using  namespace std;

common::common()
{
    
}

common::~common()
{
}

common::common(fio& new_FIO)
{
    FIO.set_fam(new_FIO.get_fam());
    FIO.set_name(new_FIO.get_name());
}

common::common(char* n_name, char* n_fam)
{
    FIO.set_fam(n_fam);
    FIO.set_name(n_name);
}

char* common::get_name() const
{
    return FIO.get_name();
}

char* common::get_fam() const
{
    return FIO.get_fam();
}

void common::set_name(char* n_name)
{
    FIO.set_name(n_name);
}

void common::set_fam(char* n_fam)
{
    FIO.set_fam(n_fam);
}

void common::show_common()
{
    cout<<"Фамилия: "<<FIO.get_fam()<<endl;
    cout<<"Имя: "<<FIO.get_name()<<endl;
}

istream& operator>>(istream& input, common& new_cmn)
{
    do
    {
        system("cls");
        char buff[4096];
        cout<<"Введите Фаимилию работника: ";
        input>>buff;
        if(!check_str(buff))
        {
            cout<<"Ощибка: Фамилия может соддержать только букву!"<<endl;
            system("pause");
            system("cls");
        }
        else
        {
            new_cmn.set_fam(buff);
            break;
        }
    }
    while (true);
    do
    {
        system("cls");
        char buff[4096];
        cout<<"Введите Имя работника: ";
        input>>buff;
        if(!check_str(buff))
        {
            cout<<"Ощибка: Имя может соддержать только букву!"<<endl;
            system("pause");
            system("cls");
        }
        else
        {
            new_cmn.set_name(buff);
            break;
        }
    }
    while (true);
    return input;
}




