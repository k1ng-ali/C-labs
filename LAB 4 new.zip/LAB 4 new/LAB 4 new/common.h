﻿#pragma once
#include <fstream>
#include "fio.h"
using namespace std;

class common
{
    fio FIO;
public:
    common();
    ~common();
    common(fio& new_FIO);
    common(char* n_name, char* n_fam);
    char* get_name() const;
    char* get_fam() const;
    void set_name(char* n_name);
    void set_fam(char* n_fam);
    
    void show_common();
    friend istream& operator>>(istream& input, common& new_cmn);
};
