﻿#include "date.h"
#include "functions.h"
#include <iostream>
#include <map>
#include <string.h>

date::date()
{
    day = 1;
    month = new char[4096];
    strcpy_s(month, 4096, " ");
    year = 2000;
}

date::~date()
{
    delete[] month;
}



int date::getDay() const
{
    return day;
}

char* date::getMonth() const
{
    return month;
}

int date::getYear() const
{
    return year;
}

void date::setDay(int nDay)
{
    if (0 < nDay < 31)
        day = nDay;
}

void date::setMonth(char* nMonth)
{
    delete[] month;
    month = new char[strlen(nMonth)+1];
    strcpy_s(month, strlen(nMonth)+1, nMonth);
}

void date::setYear(int nYear)
{
    if (1970 < nYear < 2070 )
        year = nYear;
}

istream& operator>>(istream& input, date& date)
{
    const char *months[12] =
        {"January",
        "February",
        "March",
        "April",
        "May",
        "Jun",
        "July",
        "August",
        "September",
        "October",
        "Novomber",
        "December",
    };
    
    do
    {
        system("cls");
        char buff_day[80];
        char buff_month[80];
        char buff_year[80];
        bool f = false;
        cout<<"Введите Дату через пробел 'DD Month YYYY': ";
        input>>buff_day>>buff_month>>buff_year;
        if (check_str(buff_month) || check_digit(buff_day) || check_digit(buff_year))
        {
            if (0 < atoi(buff_day) < 31 || 1970 < atoi(buff_year) < 2070)
            {
                for (int i = 0; i<12; i++)
                {
                    if (strcmp(buff_month, months[i]) == 0)
                    {
                        f = true;
                    }
                }
                if (f == true)
                {
                    date.setDay(atoi(buff_day));
                    date.setMonth(buff_month);
                    date.setYear(atoi(buff_year));
                }
                else
                {
                    cout<<"Ощибка: Неправилльный ввод, введите заново!";
                    system("pause");
                    system("cls");
                    continue;
                }
            }
            else
            {
                cout<<"Ощибка: Неправилльный ввод, введите заново!";
                system("pause");
                system("cls");
                continue;
            }
        }
        else
        {
            cout<<"Ощибка: Неправилльный ввод, введите заново!";
            system("pause");
            system("cls");
            continue;
        }
        break;
    }while (true);
    system("cls");
    return input;
}

ostream& operator<<(ostream& output, date& date)
{
    output<<date.getDay()<<" "<<date.getMonth()<<" "<<date.getYear();
    return output;
}






