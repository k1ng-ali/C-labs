﻿#pragma once
#include <istream>
using namespace std;

class date
{
    int day;
    char* month;
    int year;
public:
    date();
    ~date();
    int getDay() const;
    char* getMonth() const;
    int getYear() const;
    void setDay(int nDay);
    void setMonth(char* nMonth);
    void setYear(int nYear);

    friend istream& operator>>(istream& input, date& date);
    friend ostream& operator<<(ostream& output, date& date);
};

