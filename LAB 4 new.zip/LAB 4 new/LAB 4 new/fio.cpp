﻿#include "fio.h"

#include <string.h>


fio::fio()
{
    name = new char[4096];
    strcpy_s(name,4096, " ");
    fam = new char[4096];
    strcpy_s(fam, 4096, " ");
}

fio::fio(char* n_name, char* n_fam)
{
    delete[] name;
    delete[] fam;
    name = new char[strlen(n_name)+1];
    fam = new char[strlen(n_fam)+1];
    strcpy_s(name, strlen(n_name)+1, n_name);
    strcpy_s(fam, strlen(n_fam)+1, n_fam);
}

fio::~fio()
{
}

char* fio::get_name() const
{
    return name;
}

char* fio::get_fam() const
{
    return fam;
}

void fio::set_name(char* n_name)
{
    delete[] name;
    name = new char[strlen(n_name)+1];
    strcpy_s(name, strlen(n_name)+1, n_name);
}

void fio::set_fam(char* n_fam)
{
    delete[] fam;
    fam = new char[strlen(n_fam)+1];
    strcpy_s(fam, strlen(n_fam)+1, n_fam);
}






