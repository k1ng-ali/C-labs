﻿#pragma once

class fio
{
    char* name;
    char* fam;
public:
    fio();
    ~fio();
    fio(char* n_name, char* n_fam);
    char* get_name() const;
    char* get_fam() const;
    void set_name(char* n_name);
    void set_fam(char* n_fam);
};
