﻿#include "functions.h"

#include <iomanip>
#include <iostream>
#include <string>

int check_digit(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isdigit(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

int check_int(char* input)
{
    int i =  0;
    while (input[i])
    {
        if (input[i]!='.' && !isdigit(input[i]) && input[i] != ',' && input[i]!='-')
        {
            return 0;
        }
        if (input[i] == '.')
        {
            input[i] = ',';
        }
        i++;
    }
    return 1;
}

int check_str(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isalpha(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

void new_obj(personal& new_prs)
{
    common obj1;
    work obj2;
    personal obj3;
    cin>>obj1;
    cin>>obj2;
    cin>>obj3;
    personal obj4(obj1, obj2, obj3);
    new_prs = obj4;
    obj4.show();
}

void print_menu()
{
    cout << endl << "Выберите действие" << endl << endl;
    cout << "Добавить новые данные. . . . . . . . . . . . . . . . 1" << endl;
    cout << "Распечатать информацию о работниках. . . . . . . . . 2" << endl;
    cout << "Сортировать данные по возрасстания оклада. . . . . . 3" << endl;
    cout << "Сортировать данные по номеру отдела. . . . . . . . . 4" << endl;
    cout << "Поиск по ФИО работника . . . . . . . . . . . . . . . 5" << endl;
    cout << "Поиск по отделу. . . . . . . . . . . . . . . . . . . 6" << endl;
    cout << "Выход из программы . . . . . . . . . . . . . . . . . 7" << endl;
}

void choice_s(int& choice)
{
    do
    {
        char buff[4096];
        cout<<endl<<"Введите номер функции: ";
        cin>>buff;
        if (!check_digit(buff))
        {
            cout<<"Ощибка: введите целое число от 1 до 7 включительно!"<<endl;
            system("pause");
            system("cls");
            print_menu();
            continue;
        }
        else
        {
            choice = atoi(buff);
        }
        break;
    }
    while (true);
}

void print_header()
{
    cout<<setw(20)<<left<<"Фамилия";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Имя";
    cout<<"|  ";
    cout<<setw(15)<<left<<"Номер отдела";
    cout<<"  |";
    cout<<setw(15)<<fixed<<"Оклад";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Профессия";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Дата";
    cout<<endl;
    cout<<"================================================================================================================================="<<endl;
}

void print_data(personal* input[], int n)
{
    print_header();
    int k = 0;
    for(int i = 0; i<n;i++,k++)
    {
        cout<< *input[i];
    }
    cout<<"================================================================================================================================="<<endl;
    cout<<endl<<setw(40)<<left<<"Количество найденных записей";
    cout<<setw(20)<<fixed<<k;
    cout<<endl;
}

void find_by_name(personal* input[], int n)
{
    common FIO;
    cin>>FIO;
    cout<<"Поиск по имени: "<<FIO.get_fam()<<"   "<<FIO.get_name()<<endl;
    cout<<endl;
    print_header();
    int k = 0;
    for (int i=0; i<n;i++)
    {
        if (*input[i] == FIO)
        {
            cout<< *input[i];
            k++;
        }
    }
    if (k==0)
    {
        cout<<"Работники по имени "<<FIO.get_fam()<<"   "<<FIO.get_name()<<" не найдено!"<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k;
        cout<<endl;
    }
}

bool sort_by_slr(const personal* a, const personal* b)
{
    return a->get_slr() < b->get_slr();
}

bool sort_by_dp(const personal* a, const personal* b)
{
    return a->get_Dp() < b->get_Dp();
}

void find_by_dp(personal* input[], int n)
{
    char buff[4096];
    int k = 0;
    int dp;
    cout<<"Введите номер отдела для поиска: ";
    cin>>buff;
    do
    {
        if(!check_digit(buff))
        {
            cout<<"Ощибка: введите число!"<<endl;
            system("pause");
            system("cls");
            continue;
        }
        else
        {
            if ((atoi(buff)<=0))
            {
                cout<<"Ощибка: Введите число больше 0!"<<endl;
                system("pause");
                system("cls");
                continue;
            }
            else
            {
                dp = atoi(buff);
            }
        }
        break;
    } while(true);

    print_header();
    for (int i = 0; i<n; i++)
    {
        if ((input[i]->get_Dp() == dp))
        {
            cout<< *input[i];
            k++;
        }
    }
    if(k==0)
    {
        cout<<"Работники по одтелу "<<dp<<" не нащлось"<<endl<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k;
        cout<<endl;
    }
}

// ЧТЕНИЕ И ЗАПИСЬ ДАННЫЕ

void write_data(personal* input[], int n, const string& filename)
{
    ofstream outputFile(filename);

    if (!outputFile)
    {
        cerr<<"Не удалось открыть файл для записи!"<<endl;
        return;
    }

    for (int i = 0; i<n;i++)
    {
        outputFile<<input[i]->get_fam()<<" ";
        outputFile<<input[i]->get_name()<<" ";
        outputFile<<input[i]->get_Dp()<<" ";
        outputFile<<fixed<<input[i]->get_slr()<<" ";
        outputFile<<input[i]->get_prof()<<" ";
        outputFile<<input[i]->get_Day()<<" ";
        outputFile<<input[i]->get_month()<<" ";
        outputFile<<input[i]->get_Year()<<" "<<endl;
    }

    outputFile.close();
    cout<<"Данные успещно записаны в файл: "<<filename<<endl;
}

void read_data(personal* info[], int& n, const string& filename, int N)
{
    ifstream inputFile(filename);

    if (!inputFile)
    {
        cerr<<"Не удалось открыть файл для чтения!"<<endl;
        return;
    }

    while (!inputFile.eof())
    {
        if ((n)>=N)
        {
            cout<<"Перевышен максимальный размер массива!"<<endl;
            system("pause");
            break;
        }
        common fio;
        work wrk;
        personal prs;
        int dp;
        double slr;
        char buff_fam[4096];
        char buff_name[4096];
        char buff_dp[80];
        char buff_slr[80];
        char buff_prof[4096];
        char buff_day[80];
        char buff_month[4096];
        char buff_year[80];
        if (!(inputFile>>buff_fam>>buff_name>>buff_dp>>buff_slr>>
            buff_prof>>buff_day>>buff_month>>buff_year))
        {
            if (inputFile.eof())
            {
                break; // Если конец файла достигнут, прерываем цикл
            }
            else {
                cerr << "Ошибка чтения данных из файла." << endl;
                return;
            }
        }
        check_int(buff_slr);
        fio.set_fam(buff_fam);
        fio.set_name(buff_name);
        wrk.set_Dp(atoi(buff_dp));
        wrk.set_slr(stod(buff_slr));
        prs.set_prof(buff_prof);
        prs.set_date(atoi(buff_day), buff_month, atoi(buff_year));
        
        info[n] = new personal(fio, wrk, prs);
        (n)++;
    }

    inputFile.close();
}
