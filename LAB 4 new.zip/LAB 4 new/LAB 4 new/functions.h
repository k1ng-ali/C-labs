﻿#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#pragma once
#include "common.h"
#include "personal.h"
#include "work.h"
#include "fio.h"

int check_digit(const char* input);
int check_int(char* input);
int check_str(const char* input);
void new_obj(personal& new_prs);
void print_menu();
void choice_s(int& choice);
void print_header();
void print_data(personal* input[], int n);
bool sort_by_dp(const personal* a, const personal* b);
bool sort_by_slr(const personal* a, const personal* b);
void find_by_name(personal* input[], int n);
void find_by_dp(personal* input[], int n);

void write_data(personal* input[], int n, const string& filename);
void read_data(personal* info[], int& n, const string& filename, int N);
#endif //FUNCTIONS_H 


