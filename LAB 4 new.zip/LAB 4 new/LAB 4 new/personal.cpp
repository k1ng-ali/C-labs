﻿#include "personal.h"

#include <iomanip>

#include "functions.h"
#include <iostream>

#include "date.h"

personal::personal()
{
    prof = new char[4096];
    strcpy_s(prof, 4096, " ");
}

personal::~personal()
{
}

personal::personal(work& new_wrk, date& n_DATE, char* n_prof): work(new_wrk)
{
    delete[] prof;
    prof = new char[strlen(n_prof)+1];
    strcpy_s(prof, strlen(n_prof)+1, n_prof);
    DATE.setDay(n_DATE.getDay());
    DATE.setMonth(n_DATE.getMonth());
    DATE.setYear(n_DATE.getYear());
}

personal::personal(common& new_cmn, work& new_wrk, personal& new_prs): work(new_wrk, new_cmn)
{
    set_prof(new_prs.get_prof());
    set_date(new_prs.get_Day(), new_prs.get_month(), new_prs.get_Year());
}

personal::personal(common& new_cmn, work& new_wrk): work(new_wrk, new_cmn){}


char* personal::get_prof() const
{
    return prof;
}

date personal::get_DATE() const
{
    return DATE;
}

int personal::get_Day() const
{
    return DATE.getDay();
}

char* personal::get_month() const
{
    return DATE.getMonth();
}

int personal::get_Year() const
{
    return DATE.getYear();
}

void personal::set_prof(char* n_pfor)
{
    delete[] prof;
    prof = new char[strlen(n_pfor)];
    strcpy_s(prof, strlen(n_pfor)+1, n_pfor);
}

void personal::set_date(int n_Day, char* n_Month, int n_Year)
{
    DATE.setDay(n_Day);
    DATE.setMonth(n_Month);
    DATE.setYear(n_Year);
}

personal& personal::operator=(personal& new_prs)
{
    if (this != &new_prs)
    {
        this->set_fam(new_prs.get_fam());
        this->set_name(new_prs.get_name());
        this->set_Dp(new_prs.get_Dp());
        this->set_slr(new_prs.get_slr());
        this->set_prof(new_prs.get_prof());
        this->set_date(new_prs.get_Day(), new_prs.get_month(), new_prs.get_Year());
    }
    return *this;
}

bool personal::operator==(const common& other) const
{
    return (strcmp(get_fam(), other.get_fam()) == 0 && strcmp(get_name(), other.get_name()) == 0);
}


void personal::show()
{
    show_work();
    cout<<"Профессия: "<<prof<<endl;
    cout<<"Дата: "<<DATE.getDay()<<"."<<DATE.getMonth()<<"."<<DATE.getYear()<<endl;
}

istream& operator>>(istream& input, personal& new_prs)
{
    do
    {
        system("cls");
        char buff[4096];
        cout<<"Введите профессию работника: ";
        input>>buff;
        if(!check_str(buff))
        {
            cout<<"Ощибка: Имя может соддержать только букву!"<<endl;
            system("pause");
            system("cls");
        }
        else
        {
            new_prs.set_prof(buff);
            break;
        }
    }while (true);
    date Date;
    cin>>Date;
    new_prs.set_date(Date.getDay(), Date.getMonth(), Date.getYear());
    return input;
}

ostream& operator<<(ostream& output, personal& output_prs)
{
    output<<setw(20)<<left<<output_prs.get_fam();
    output<<"|  ";
    output<<setw(20)<<left<<output_prs.get_name();
    output<<"|  ";
    output<<setw(15)<<left<<output_prs.get_Dp();
    output<<"  |";
    output<<setw(15)<<fixed<<setprecision(2)<<output_prs.get_slr();
    output<<"|  ";
    output<<setw(20)<<left<<output_prs.get_prof();
    output<<"|  ";
    output<<left<<output_prs.get_Day()<<left<<"."<<left<<output_prs.get_month()<<left<<"."<<left<<output_prs.get_Year();
    cout<<endl;
    return output;
}



