﻿#pragma once
#include "common.h"
#include "date.h"
#include "work.h"

class personal: public work
{
    char* prof;
    date DATE;
public:
    personal();
    ~personal();
    personal(work& new_wrk, date& n_DATE, char* n_prof);
    personal(common& new_cmn, work& new_wrk, personal& new_prs);
    personal(common& new_cmn, work& new_wrk);
    char* get_prof() const;
    date get_DATE() const;
    int get_Day() const;
    char* get_month() const;
    int get_Year() const;
    void set_prof(char* n_pfor);
    void set_date(int n_Day, char* n_Month, int n_Year);

    personal& operator=(personal& new_prs);
    bool operator==(const common& other)const;
    void show();
    friend istream& operator>>(istream& input, personal& new_prs);
    friend ostream& operator<<(ostream& output, personal& output_prs);
    
};
