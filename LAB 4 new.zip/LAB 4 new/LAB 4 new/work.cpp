﻿#include "work.h"
#include "functions.h"
#include <iostream>

using namespace std;

work::work()
{
    Dp = 0;
    salary = 0;
}

work::work(common& new_cmn, int n_dp, float n_slr):common(new_cmn)
{
    Dp = n_dp;
    salary = n_slr;
}

work::work(common& new_cmn): common(new_cmn){}

work::work(work& new_wrk, common& new_cmn):common(new_cmn)
{
    Dp = new_wrk.get_Dp();
    salary = new_wrk.get_slr();
}

work::~work()
{
    
}

int work::get_Dp() const
{
    return Dp;
}

float work::get_slr() const
{
    return salary;
}

void work::set_Dp(int n_dp)
{
    Dp = n_dp;
}

void work::set_slr(float n_slr)
{
    salary = n_slr;
}

void work::show_work()
{
    show_common();
    cout<<"Отдел: "<<Dp<<endl;
    cout<<"Оклад: "<<salary<<endl;
}

istream& operator>>(istream& input, work& new_wrk)
{
    do
    {
        system("cls");
        char buff[4096];
        cout<<"Введите номер отдела: ";
        input>>buff;
        if(!check_digit(buff))
        {
            cout<<"Ощибка! Введите целое число."<<endl;
            system("pause");
            system("cls");
        }
        else
        {
            new_wrk.set_Dp(atoi(buff));
            break;
        }
    }
    while (true);
    do
    {
        system("cls");
        char buff[4096];
        cout<<"Введите оклад: ";
        input>>buff;
        if(!check_int(buff))
        {
            cout<<"Ощибка! Введите число."<<endl;
            system("pause");
            system("cls");
        }
        else
        {
            new_wrk.set_slr(atof(buff));
            break;
        }
    }
    while (true);
    return  input;
}





