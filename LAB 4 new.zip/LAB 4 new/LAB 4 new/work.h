﻿#pragma once
#include "common.h"

class work: public common
{
    int Dp;
    float salary;
public:
    work();
    ~work();
    work(common& new_cmn, int n_dp, float n_slr);
    work(common& new_cmn);
    work(work& new_wrk, common& new_cmn);
    int get_Dp() const;
    float get_slr() const;
    void set_Dp(int n_dp);
    void set_slr(float n_slr);

    void show_work();
    friend istream& operator>>(istream& input, work& new_wrk);
};
