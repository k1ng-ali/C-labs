﻿#include "functions.h"
#include "worker.h"
#include <iomanip>
#include <iostream>
#include <locale>
#include <algorithm>
#include <fstream>

using namespace std;

/*ostream& operator<<(ostream& output, const worker& worker) {
    return worker.operator<<(output);
}*/

int check_digit(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isdigit(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

int check_int(char* input)
{
    int i =  0;
    while (input[i])
    {
        if (input[i]!='.' && !isdigit(input[i]) && input[i] != ',' && input[i]!='-')
        {
            return 0;
        }
        if (input[i] == '.')
        {
            input[i] = ',';
        }
        i++;
    }
    return 1;
}

int check_str(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isalpha(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

void print_Heading()
{
    cout<<setw(30)<<left<<"Фамилия";
    cout<<"|  ";
    cout<<setw(30)<<left<<"Имя";
    cout<<"|  ";
    cout<<setw(15)<<left<<"Номер отдела";
    cout<<"  |";
    cout<<setw(20)<<fixed<<"Оклад";
    cout<<endl;
    cout<<"========================================================================================================="<<endl;

}

void print_menu()
{
    cout << endl << "Выберите действие" << endl << endl;
    cout << "Добавить новые данные. . . . . . . . . . . . . . . . 1" << endl;
    cout << "Распечатать информацию о работниках. . . . . . . . . 2" << endl;
    cout << "Сортировать данные по возрасстания оклада. . . . . . 3" << endl;
    cout << "Сортировать данные по номеру отдела. . . . . . . . . 4" << endl;
    cout << "Поиск по ФИО работника . . . . . . . . . . . . . . . 5" << endl;
    cout << "Поиск по отделу. . . . . . . . . . . . . . . . . . . 6" << endl;
    cout << "Выход из программы . . . . . . . . . . . . . . . . . 7" << endl;
}

bool sort_by_slr(const worker* a, const worker* b)
{
    return a->get_Slr() < b->get_Slr(); 
}

bool sort_by_dp(const worker* a, const worker* b)
{
    return a->get_Dp() < b->get_Dp();
}

void find_by_name(worker* info[], int n)
{
    man fio;
    cin>>fio;
    cout<<"Поиск по имени: "<<fio.get_fam()<<"   "<<fio.get_name()<<endl;
    cout<<endl;
    print_Heading();
    int k = 0;
    for (int i=0; i<n;i++)
    {
        if (*info[i] == fio)
        {
            cout<< *info[i];
            k++;
        }
    }
    if (k==0)
    {
        cout<<"Работники по имени "<<fio.get_fam()<<"   "<<fio.get_name()<<" не найдено!"<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k;
        cout<<endl;
    }
}

void find_by_dp(worker* info[], int n)
{
    char buff[4096];
    int k = 0;
    int dp;
    cout<<"Введите номер отдела для поиска: ";
    cin>>buff;
    do
    {
        if(!check_digit(buff))
        {
            cout<<"Ощибка: введите число!"<<endl;
            system("pause");
            system("cls");
            continue;
        }
        else
        {
            if ((atoi(buff)<=0))
            {
                cout<<"Ощибка: Введите число больше 0!"<<endl;
                system("pause");
                system("cls");
                continue;
            }
            else
            {
                dp = atoi(buff);
            }
        }
        break;
    } while(true);

    print_Heading();
    for (int i = 0; i<n; i++)
    {
        if ((info[i]->get_Dp() == dp))
        {
            cout<< *info[i];
            k++;
        }
    }
    if(k==0)
    {
        cout<<"Работники по одтелу "<<dp<<" не нащлось"<<endl<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k;
        cout<<endl;
    }
}



void choice_s(int& choise)
{
    do
    {
        char buff[4096];
        cout<<endl<<"Введите номер функции: ";
        cin>>buff;
        if (!check_digit(buff))
        {
            cout<<"Ощибка: введите целое число от 1 до 7 включительно!"<<endl;
            system("pause");
            system("cls");
            print_menu();
            continue;
        }
        else
        {
            choise = atoi(buff);
        }
        break;
    }
    while (true);
}

void print_data(worker* info[], int n)
{
    print_Heading();
    int k = 0;
    for(int i = 0; i<n;i++,k++)
    {
        cout<< *info[i];
    }
    cout<<endl<<setw(40)<<left<<"Количество найденных записей";
    cout<<setw(20)<<fixed<<k;
    cout<<endl;
}

// ЧТЕНИЕ И ЗАПИСЬ ДАННЫЕ

void write_data(worker* info[], int n, const string& filename)
{
    ofstream outputFile(filename);

    if (!outputFile)
    {
        cerr<<"Не удалось открыть файл для записи!"<<endl;
        return;
    }

    for (int i = 0; i<n;i++)
    {
        outputFile<<info[i]->get_fam()<<" ";
        outputFile<<info[i]->get_name()<<" ";
        outputFile<<info[i]->get_Dp()<<" ";
        outputFile<<info[i]->get_Slr()<<" "<<endl;
    }

    outputFile.close();
    cout<<"Данные успещно записаны в файл: "<<filename<<endl;
}

void read_data(worker* info[], int& n, const string& filename, int N)
{
    ifstream inputFile(filename);

    if (!inputFile)
    {
        cerr<<"Не удалось открыть файл для чтения!"<<endl;
        return;
    }

    while (!inputFile.eof())
    {
        if ((n)>=N)
        {
            cout<<"Перевышен максимальный размер массива!"<<endl;
            system("pause");
            break;
        }
        info[n] = new worker;
        man fio;
        int dp;
        double slr;
        char dp_buff[4096];
        char slr_buff[4096];
        char buffFam[4096];
        char buffName[4096];
        if (!(inputFile>>buffFam>>buffName>>dp_buff>>slr_buff))
        {
            if (inputFile.eof())
            {
                break; // Если конец файла достигнут, прерываем цикл
            }
            else {
                cerr << "Ошибка чтения данных из файла." << endl;
                return;
            }
        }
        check_int(slr_buff);
        dp = atoi(dp_buff);
        slr = atof(slr_buff);
        fio.set_fam(buffFam);
        fio.set_name(buffName);
        
        info[n] = new worker(fio, dp, slr);
        (n)++;
    }

    inputFile.close();
}

