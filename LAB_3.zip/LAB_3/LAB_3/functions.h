﻿#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include "worker.h"

using namespace std;

//ostream& operator<<(ostream& output, const worker& worker);
int check_digit(const char* input);
int check_int(char* input);
int check_str(const char* input);
void print_Heading();
void print_menu();

bool sort_by_slr(const worker* a, const worker* b);
bool sort_by_dp(const worker* a, const worker* b);
void find_by_name(worker* info[], int n);
void find_by_dp(worker* info[], int n);

void choice_s(int& choise);
void print_data(worker* info[], int n);


void write_data(worker* info[], int n, const string& filename);
void read_data(worker* info[], int& n, const string& filename, int N);


#endif // FUNCTIONS_H