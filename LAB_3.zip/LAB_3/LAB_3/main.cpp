#include <algorithm>

#include "worker.h"
#include "man.h"
#include "functions.h"
#include <locale.h>
#include <iostream>

using  namespace std;


int main(int argc, char* argv[])
{
    setlocale(LC_ALL, "RUS");
    const int N = 100;
    int n = 0;
    int choice;
    worker* MWor[N];
    worker man;

    read_data(MWor, n, "data.txt", N);

    do
    {
        system("cls");
        print_menu();
        choice_s(choice);

        switch (choice)
        {
        case 1:
            if (n<N)
            {
                MWor[n] = new worker;
                cin>> *MWor[n];
                n++;
            }
            else
            {
                cout<<"Перевышен максимальный размер массива!"<<endl;
            }
            cout<<"Успещно добавлено!"<<endl;
            system("pause");
            system("cls");
            break;
        case 2:
            system("cls");
            print_data(MWor, n);
            system("pause");
            system("cls");
            break;
        case 3:
            system("cls");
            sort(MWor, MWor+n, sort_by_slr);
            cout<<"Данные успещно сортированы по возратанию оклада!"<<endl;
            system("pause");
            system("cls");
            break;
        case 4:
            system("cls");
            sort(MWor, MWor+n, sort_by_dp);
            cout <<"Данные успещно сортированы по номеру отдела!"<<endl;
            system("pause");
            system("cls");
            break;
        case 5:
            system("cls");
            find_by_name(MWor, n);
            system("pause");
            system("cls");
            break;
        case 6:
            system("cls");
            find_by_dp(MWor, n);
            system("pause");
            system("cls");
            break;
        case 7:
            system("cls");
            cout<<"Выход из программы"<<endl;
            break;
        default:
            cout << "Ощибка: введите число от 1 до 5 включительно!" << endl;
            system("pause");        
        }
            
    }while (choice != 7);

    write_data(MWor, n, "data.txt");

    for (int i = 0; i<n; i++)
    {
        delete MWor[i];
    }

    return 0;
}
