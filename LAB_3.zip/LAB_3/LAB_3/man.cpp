﻿#include "man.h"
#include "functions.h"
#include <iostream>
#include <string.h>

man::man()
{
    name = new char[4096];
    strcpy_s(name,4096," ");
    fam = new char[4096];
    strcpy_s(fam,4096," ");
}

man::~man()
{
    delete[] name;
    delete[] fam;
}

char* man::get_name() const
{
    return name;
}

char* man::get_fam() const
{
    return fam;
}

void man::set_name(const char* new_name)
{
    delete[] name;
    name = new char[strlen(new_name)+1];
    strcpy_s(name,strlen(new_name)+1,new_name);
}

void man::set_fam(const char* new_fam)
{
    delete[] fam;
    fam = new char[strlen(new_fam)+1];
    strcpy_s(fam, strlen(new_fam)+1, new_fam);
}

istream& operator>>(istream& input, man& man)
{
    system("cls");
    do
    {
        char buff[4096];
        cout<<"Введите фамилю работника: ";
        input>>buff;
        if (!check_str(buff))
        {
            cout<<"Ощибка: Фамилия должно соддержать только букву!"<<endl;
            system("pause");
            system("cls");
        }
        else
        {
            man.set_fam(buff);
            break;
        }
    }while (true);
    system("cls");

    do
    {
        char buff[4096];
        cout<<"Фамилия: "<<man.get_fam()<<endl;
        cout<<"Введите имя работника: ";
        input>>buff;
        if (!check_str(buff))
        {
            cout<<"Ощибка: Имя должно соддержать только букву!"<<endl;
            system("pause");
            system("cls");
        }
        else
        {
            man.set_name(buff);
            break;
        }
    }while (true);
    system("cls");
    cout<<endl;
    return input;
}









