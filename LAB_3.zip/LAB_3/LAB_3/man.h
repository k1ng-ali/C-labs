﻿#pragma once
#include <istream>

using namespace  std;

class man
{
    char* name;
    char* fam;
public:
    man();
    ~man();
    char* get_name() const;
    char* get_fam() const;
    void set_name(const char* new_name);
    void set_fam(const char* new_fam);

    friend istream& operator>>(istream& input, man& FIO_new);
};
