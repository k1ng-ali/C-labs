﻿#pragma once
#include <istream>
using namespace std;

#include "man.h"

class worker
{
    man FIO;
    int departament;
    float salary;
public:
    worker();
    ~worker();
    worker(man& FIO_new, int dp = 0, float slr = 0);
    char* get_name() const;
    char* get_fam() const;
    int get_Dp() const;
    float get_Slr() const;
    void set_FIO(man& FIO_new);
    void set_Dp(int dp);
    void set_Slr(float slr);
    
    friend ostream& operator<<(ostream& output, worker& worker);
    bool operator==(const man& FIO_other) const;
    friend istream& operator>>(istream& input, worker& worker);
    
};
