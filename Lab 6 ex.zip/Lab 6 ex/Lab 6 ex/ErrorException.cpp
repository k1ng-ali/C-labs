﻿#include "ErrorException.h"

#include <string>

ErrorException::ErrorException(const char* msg) : message(msg) {}

const char* ErrorException::what() const noexcept {
    return message;
}

char* ErrorException::valid_char() {
    char input[4096];
    //cout << "Введите букву: ";
    cin >> input;
    if (!check_str(input)) {
        system("cls");
        throw ErrorException("Ошибка: Ввод должен быть буквой.");
    }
    return input;
}

int ErrorException::valid_int() {
    char num[4096];
    //cout << "Введите число: ";
    cin >> num;
    if (!check_int(num)) {
        system("cls");
        throw ErrorException("Ошибка: Ввод должен быть целым числом.");
    }
    return atoi(num);
}

float ErrorException::valid_digit() {
    char num[4096];
    //cout << "Введите число: ";
    cin >> num;
    if (!check_digit(num)) {
        system("cls");
        throw ErrorException("Ошибка: Ввод должен быть целым или вещественным числом.");
    }
    return stod(num);
}

date& ErrorException::valid_date()
{
    date n_date;
    char buff_day[80];
    char buff_month[80];
    char buff_year[80];
    cin>>buff_day>>buff_month>>buff_year;
    if (check_digit(buff_month) && check_digit(buff_day) && check_digit(buff_year))
    {
        if (0 < atoi(buff_day) && atoi(buff_day) < 31 &&
            0 < atoi(buff_month) && atoi(buff_month) < 13 &&
            1970 < atoi(buff_year) && atoi(buff_year) < 2070)
        {
            
            n_date.setDay(atoi(buff_day));
            n_date.setMonth(atoi(buff_month));
            n_date.setYear(atoi(buff_year));
        }
        else
        {
            system("cls");
            throw ErrorException("Ощибка: Неправилльный ввод, введите заново!");
        }
    }
    else
    {
        system("cls");
        throw ErrorException("Ощибка: Неправилльный ввод, введите заново!");
    }
    return n_date;
}


bool ErrorException::check_str(const char* str) {
    for (size_t i = 0; i < strlen(str); ++i) {
        if (!isalpha(str[i])) {
            return false;
        }
    }
    return true;
}

bool ErrorException::check_digit(char* str) {
    for (size_t i = 0; i < strlen(str); ++i) {
        if (str[i]!='.' && !isdigit(str[i]) && str[i] != ',' && str[i]!='-')
        {
            return false;
        }
        if (str[i] == '.')
        {
            str[i] = ',';
        }
    }
    return true;
}

bool ErrorException::check_int(const char* str) {
    for (size_t i = 0; i < strlen(str); ++i) {
        if (!isdigit(str[i])) {
            return false;
        }
    }
    return true;
}
