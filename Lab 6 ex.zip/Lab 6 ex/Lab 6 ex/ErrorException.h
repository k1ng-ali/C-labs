﻿#pragma once
#include <iostream>
#include "date.h"
#include <stdexcept>
#include <cctype>
#include <cstring>

using namespace std;

class ErrorException : public exception
{
private:
    const char* message;
public:
    ErrorException(const char* msg);

    const char* what() const noexcept override;
    static char* valid_char();
    static int valid_int();
    static float valid_digit();
    static date& valid_date();
    
    // Добавим эти функции для проверки строк и цифр
    static bool check_str(const char* str);
    static bool check_int(const char* str);
    static bool check_digit(char* str);
};
