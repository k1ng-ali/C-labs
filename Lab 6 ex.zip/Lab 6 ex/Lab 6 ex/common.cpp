﻿#include "common.h"
#include "functions.h"
#include <iostream>
using  namespace std;

common::common()
{
    
}

common::~common()
{
}

common::common(fio& new_FIO)
{
    FIO.set_fam(new_FIO.get_fam());
    FIO.set_name(new_FIO.get_name());
}

common::common(char* n_name, char* n_fam)
{
    FIO.set_fam(n_fam);
    FIO.set_name(n_name);
}

char* common::get_name() const
{
    return FIO.get_name();
}

char* common::get_fam() const
{
    return FIO.get_fam();
}

void common::set_name(char* n_name)
{
    FIO.set_name(n_name);
}

void common::set_fam(char* n_fam)
{
    FIO.set_fam(n_fam);
}

void common::show()
{
    cout<<"Фамилия: "<<FIO.get_fam()<<endl;
    cout<<"Имя: "<<FIO.get_name()<<endl;
}

istream& operator>>(istream& input, common& new_cmn)
{
    system("cls");
    do
    {
        try
        {
            cout<<"Введите Фамилию: ";
            new_cmn.set_fam(ErrorException::valid_char());
            break;
        }
        catch (const ErrorException& ex)
        {
            cerr << ex.what()<<endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
        }
    }
    while (true);
    system("cls");
    do
    {
        try
        {
            cout<<"Введите Имя: ";
            new_cmn.set_name(ErrorException::valid_char());
            break;
        }
        catch (const ErrorException& ex)
        {
            cerr << ex.what()<<endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
        }
    }
    while (true);
    return input;
}




