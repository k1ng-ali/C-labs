﻿#include "date.h"
#include "functions.h"
#include <iostream>
#include <map>
#include <string.h>

date::date()
{
    day = 1;
    month = 1;
    year = 2000;
}

date::date(date& ndate)
{
    setDay(ndate.getDay());
    setMonth(ndate.getMonth());
    setYear(ndate.getYear());
}

date::~date()
{
}



int date::getDay() const
{
    return day;
}

int date::getMonth() const
{
    return month;
}

int date::getYear() const
{
    return year;
}

void date::set_date(date& n_DATE)
{
    setDay(n_DATE.getDay());
    setMonth(n_DATE.getMonth());
    setYear(n_DATE.getYear());
}

void date::setDay(int nDay)
{
    if (0 < nDay < 31)
        day = nDay;
}

void date::setMonth(int nMonth)
{
    if (0< nMonth < 13)
        month = nMonth;
}

void date::setYear(int nYear)
{
    if (1970 < nYear < 2070 )
        year = nYear;
}

istream& operator>>(istream& input, date& date)
{
    return input;
}

ostream& operator<<(ostream& output, date& date)
{
    output<<date.getDay()<<" "<<date.getMonth()<<" "<<date.getYear();
    return output;
}






