﻿#pragma once
#include <istream>
using namespace std;

class date
{
    int day;
    int month;
    int year;
public:
    date();
    date(date& n_date);
    ~date();
    int getDay() const;
    int getMonth() const;
    int getYear() const;
    void set_date(date& n_DATE);
    void setDay(int nDay);
    void setMonth(int nMonth);
    void setYear(int nYear);

    friend istream& operator>>(istream& input, date& date);
    friend ostream& operator<<(ostream& output, date& date);
};

