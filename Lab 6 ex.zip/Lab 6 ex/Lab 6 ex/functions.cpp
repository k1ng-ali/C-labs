﻿#include "functions.h"

#include <iomanip>
#include <iostream>
#include <string>

int check_digit(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isdigit(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

int check_int(char* input)
{
    int i =  0;
    while (input[i])
    {
        if (input[i]!='.' && !isdigit(input[i]) && input[i] != ',' && input[i]!='-')
        {
            return 0;
        }
        if (input[i] == '.')
        {
            input[i] = ',';
        }
        i++;
    }
    return 1;
}

int check_str(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isalpha(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

void new_prs(common* new_cmn[], int n)
{
    new_cmn[n] = new personal;
    cin>>*new_cmn[n];
    cin>>dynamic_cast<personal&>(*new_cmn[n]);
}

void new_wrk(common* new_cmn[], int n)
{
    new_cmn[n] = new work;
    cin>>*new_cmn[n];
    cin>>dynamic_cast<work&>(*new_cmn[n]);
}

void new_obj(common* new_cmn[], int& n)
{
    int choice = 0;
    do
    {
        system("cls");
        cout << endl << "Выберите действие" << endl << endl;
        cout << "Создать объект класса 'worker'. . . . . . . . . . . 1" << endl;
        cout << "Создать объект класса 'personnel' . . . . . . . . . 2" << endl;
        cout << "Выход в главное меню. . . . . . . . . . . . . . . . 3" << endl;
        choice_s(choice);
        
        switch (choice)
        {
        case 1:
            new_wrk(new_cmn, n);
            n++;
            cout << "Объект успешно создан!" << endl;
            system("pause");
            break;
        case 2:
            new_prs(new_cmn, n);
            n++;
            cout << "Объект успешно создан!" << endl;
            system("pause");
            break;
        case 3:
            cout <<  "Выход..."<<endl;
            system("cls");
            break;
        default:
            cout<< "Введите число от 1 до 3 включительно!" << endl;
            system("pause");
        }
    }
    while (choice != 3);
    
}

void print_menu()
{
    cout << endl << "Выберите действие" << endl << endl;
    cout << "Добавить новые данные. . . . . . . . . . . . . . . . 1" << endl;
    cout << "Распечатать информацию о работниках. . . . . . . . . 2" << endl;
    cout << "Поиск по ФИО работника . . . . . . . . . . . . . . . 3" << endl;
    cout << "Поиск по отделу. . . . . . . . . . . . . . . . . . . 4" << endl;
    cout << "Поиск работников проработавших больше 10 лет . . . . 5" << endl;
    cout << "Выход из программы . . . . . . . . . . . . . . . . . 6" << endl;
}

void choice_s(int& choice)
{
    do
    {
        char buff[4096];
        cout<<endl<<"Введите номер функции: ";
        cin>>buff;
        if (!check_digit(buff))
        {
            cout<<"Ощибка: введите целое число!"<<endl;
            system("pause");
            system("cls");
            print_menu();
            continue;
        }
        else
        {
            choice = atoi(buff);
        }
        break;
    }
    while (true);
}

void print_header()
{
    cout<<setw(20)<<left<<"Фамилия";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Имя";
    cout<<"|  ";
    cout<<setw(15)<<left<<"Номер отдела";
    cout<<"  |";
    cout<<setw(15)<<fixed<<"Оклад";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Профессия";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Дата";
    cout<<endl;
    cout<<"================================================================================================================================="<<endl;
}

void print_header_wrk()
{
    cout<<setw(20)<<left<<"Фамилия";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Имя";
    cout<<"|  ";
    cout<<setw(10)<<left<<"Номер отдела";
    cout<<"|  ";
    cout<<setw(15)<<fixed<<"Оклад";
    cout<<endl;
    cout<<"===================================================================================================="<<endl;

}

void print_header_prs()
{
    cout<<setw(20)<<left<<"Фамилия";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Имя";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Профессия";
    cout<<"|  ";
    cout<<setw(20)<<left<<"Дата";
    cout<<endl;
    cout<<"===================================================================================================="<<endl;

}



void print_data(common* input[], int n)
{
    system("cls");
    print_header_prs();
    int k = 0;
    for(int i = 0; i<n;i++)
    {
        if (personal* p = dynamic_cast<personal*>(input[i]))
        {
            p->show();
            k++;
        }
    }
    cout<<"===================================================================================================="<<endl;
    cout<<endl<<setw(40)<<left<<"Количество найденных записей";
    cout<<setw(20)<<fixed<<k;
    cout<<endl<<endl;

    print_header_wrk();
    k = 0;
    for(int i = 0; i<n;i++)
    {
        if (work* w = dynamic_cast<work*>(input[i]))
        {
            w->show();
            k++;
        }
    }
    cout<<"===================================================================================================="<<endl;
    cout<<endl<<setw(40)<<left<<"Количество найденных записей";
    cout<<setw(20)<<fixed<<k;
    cout<<endl;
}

bool sort_by_slr(const work* a, const work* b)
{
    return a->get_slr() < b->get_slr();
}

bool sort_by_dp(const work* a, const work* b)
{
    return a->get_Dp() < b->get_Dp();
}


void find_by_name(common* input[], int n)
{
    common FIO;
    cin>>FIO;
    cout<<"Поиск по имени: "<<FIO.get_fam()<<"   "<<FIO.get_name()<<endl;
    cout<<endl;
    print_header_prs();
    int k = 0;
    for (int i=0; i<n;i++)
    {
        if (personal* p = dynamic_cast<personal*>(input[i]))
        {
            if (*p == FIO)
            {
                p->show();
                k++;
            }
        }
    }
    print_header_wrk();
    int j = 0;
    for (int i=0; i<n;i++)
    {
        if (work* w = dynamic_cast<work*>(input[i]))
        {
            if (*w == FIO)
            {
                w->show();
                j++;
            }
        }
    }
    
    if (k==0 && j==0)
    {
        cout<<"Работники по имени "<<FIO.get_fam()<<"   "<<FIO.get_name()<<" не найдено!"<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k+j;
        cout<<endl;
    }
}

void find_worker(common* input[], int n)
{
    date* n_date = new date;
    system("cls");
    do
    {
        try
        {
            cout<<"Введите сегодняшнюю дату: ";
            n_date->set_date(ErrorException::valid_date());
            break;
        }
        catch (const ErrorException& ex)
        {
            cerr << ex.what()<<endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
    while (true);
    print_header_prs();
    int k = 0;
    for (int i=0; i<n; i++)
    {
        if (personal* pr = dynamic_cast<personal*>(input[i]))
        {
            if (((n_date->getYear() - pr->get_Year()) > 10)
            || (((n_date->getYear() - pr->get_Year()) == 10)
                && ((n_date->getMonth() > pr->get_month())
                    || ((n_date->getMonth() == pr->get_month())
                        && (n_date->getDay() > pr->get_Day())))))
            {
                pr->show();
                k++;
            }
        }
    }
    if(k==0)
    {
        cout<<"Работник работавший больше 10 лет не нашлось"<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k;
        cout<<endl;
    }
    
}


void find_by_dp(common* input[], int n)
{
    char buff[4096];

    int dp;
    cout<<"Введите номер отдела для поиска: ";
    cin>>buff;
    do
    {
        if(!check_digit(buff))
        {
            cout<<"Ощибка: введите число!"<<endl;
            system("pause");
            system("cls");
            continue;
        }
        else
        {
            if ((atoi(buff)<=0))
            {
                cout<<"Ощибка: Введите число больше 0!"<<endl;
                system("pause");
                system("cls");
                continue;
            }
            else
            {
                dp = atoi(buff);
            }
        }
        break;
    } while(true);
    int k = 0;
    print_header_wrk();
    for (int i = 0; i<n; i++)
    {
        if (work* w = dynamic_cast<work*>(input[i]))
        {
            if (dp == w->get_Dp())
            {
                w->show();
                k++;
            }
        }
    }
    if(k==0)
    {
        cout<<"Работники по одтелу "<<dp<<" не нащлось"<<endl<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k;
        cout<<endl;
    }
}

// ЧТЕНИЕ И ЗАПИСЬ ДАННЫЕ

void write_data(common* input[], int n, const string& filename)
{
    ofstream outputFile(filename);

    if (!outputFile)
    {
        cerr<<"Не удалось открыть файл для записи!"<<endl;
        return;
    }

    for (int i = 0; i<n;i++)
    {
        if (personal* p = dynamic_cast<personal*>(input[i]))
        {
            outputFile<<"prs"<<" ";
            outputFile<<p->get_fam()<<" ";
            outputFile<<p->get_name()<<" ";
            outputFile<<p->get_prof()<<" ";
            outputFile<<p->get_Day()<<" ";
            outputFile<<p->get_month()<<" ";
            outputFile<<p->get_Year()<<" "<<endl;
        }
        if (work* w = dynamic_cast<work*>(input[i]))
        {
            outputFile<<"wrk"<<" ";
            outputFile<<w->get_fam()<<" ";
            outputFile<<w->get_name()<<" ";
            outputFile<<w->get_Dp()<<" ";
            outputFile<<fixed<<setprecision(2)<<w->get_slr()<<" "<<endl;
        }
    }

    outputFile.close();
    cout<<"Данные успещно записаны в файл: "<<filename<<endl;
}

void read_data(common* info[], int& n, const string& filename, int N)
{
    ifstream inputFile(filename);

    if (!inputFile)
    {
        cerr << "Не удалось открыть файл для чтения!" << endl;
        return;
    }

    while (!inputFile.eof())
    {
        if ((n) >= N)
        {
            cout << "Перевышен максимальный размер массива!" << endl;
            system("pause");
            break;
        }

        char buff_key[80];
        inputFile >> buff_key;

        if (strcmp(buff_key, "prs") == 0)
        {
            char buff_fam[4096], buff_name[4096], buff_prof[4096], buff_day[80], buff_month[4096], buff_year[80];
            if (!(inputFile >> buff_fam >> buff_name >> buff_prof >> buff_day >> buff_month >> buff_year))
            {
                if (inputFile.eof())
                {
                    break; // Если конец файла достигнут, прерываем цикл
                }
                else
                {
                    cerr << "Ошибка чтения данных из файла." << endl;
                    return;
                }
            }

            info[n] = new personal;
            info[n]->set_fam(buff_fam);
            info[n]->set_name(buff_name);
            dynamic_cast<personal*>(info[n])->set_prof(buff_prof);
            dynamic_cast<personal*>(info[n])->set_date(atoi(buff_day), atoi(buff_month), atoi(buff_year));
            (n)++;
        }
        else if (strcmp(buff_key, "wrk") == 0)
        {
            char buff_fam[4096], buff_name[4096], buff_dp[80], buff_slr[80];
            if (!(inputFile >> buff_fam >> buff_name >> buff_dp >> buff_slr))
            {
                if (inputFile.eof())
                {
                    break; // Если конец файла достигнут, прерываем цикл
                }
                else
                {
                    cerr << "Ошибка чтения данных из файла." << endl;
                    return;
                }
            }

            info[n] = new work;
            info[n]->set_fam(buff_fam);
            info[n]->set_name(buff_name);
            dynamic_cast<work*>(info[n])->set_Dp(atoi(buff_dp));
            check_int(buff_slr);
            dynamic_cast<work*>(info[n])->set_slr(stod(buff_slr));
            (n)++;
        }
    }

    inputFile.close();
}

