﻿#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#pragma once
#include "common.h"
#include "personal.h"

int check_digit(const char* input);
int check_int(char* input);
int check_str(const char* input);
void new_obj(common* new_cmn[], int& n);
void new_prs(common* new_cmn[], int n);
void new_wrk(common* new_cmn[], int n);
void print_menu();
void choice_s(int& choice);
void print_header();
void print_header_wrk();
void print_header_prs();

void print_data(common* input[], int n);
bool sort_by_dp(const work* a, const work* b);
bool sort_by_slr(const work* a, const work* b);
void find_by_name(common* input[], int n);
void find_by_dp(common* input[], int n);
void find_worker(common* input[], int n);

void write_data(common* input[], int n, const string& filename);
void read_data(common* info[], int& n, const string& filename, int N);

#endif //FUNCTIONS_H 


