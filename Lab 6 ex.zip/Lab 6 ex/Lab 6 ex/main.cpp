#include "work.h"
#include "common.h"
#include "date.h"
#include "personal.h"
#include <fstream>
#include "fio.h"
#include "functions.h"
#include <locale.h>
#include <algorithm>
#include <iostream>
using namespace std;

int main()
{
    setlocale(LC_ALL, "RUS");
    const int N = 100;
    int n = 0;
    int choice;
    common* Cper[N];

    read_data(Cper, n, "new_data.txt", N);
    do
    {
        system("cls");
        print_menu();
        choice_s(choice);

        switch (choice)
        {
        case 1:
            if (n<N)
            {
                system("cls");
                new_obj(Cper, n);
            }
            else
            {
                cout<<"Перевышен максимальный размер массива!"<<endl;
            }
            system("cls");
            break;
        case 2:
            system("cls");
            print_data(Cper, n);
            system("pause");
            system("cls");
            break;
        case 3:
            system("cls");
            find_by_name(Cper, n);
            system("pause");
            system("cls");
            break;
        case 4:
            system("cls");
            find_by_dp(Cper, n);
            system("pause");
            system("cls");
            break;
        case 5:
            system("cls");
            find_worker(Cper, n);
            system("pause");
            system("cls");
        case 6:
            system("cls");
            cout<<"Выход из программы"<<endl;
            break;
        default:
            cout <<"Ощибка: введите число от 1 до 6 включительно!" << endl;
            system("pause"); 
        }
      
    }
    while (choice != 6);

    write_data(Cper, n, "new_data.txt");

    for (int i = 0; i<n; i++)
    {
        delete Cper[i];
    }
   
    return 1;
}
