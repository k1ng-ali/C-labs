﻿#include "personal.h"

#include <iomanip>

#include "functions.h"
#include <iostream>

#include "date.h"

personal::personal()
{
    prof = new char[4096];
    strcpy_s(prof, 4096, " ");
}

personal::~personal()
{
}

personal::personal(date& n_DATE, char* n_prof)
{
    delete[] prof;
    prof = new char[strlen(n_prof)+1];
    strcpy_s(prof, strlen(n_prof)+1, n_prof);
    DATE.setDay(n_DATE.getDay());
    DATE.setMonth(n_DATE.getMonth());
    DATE.setYear(n_DATE.getYear());
}

personal::personal(common& new_cmn, personal& new_prs): common(new_cmn)
{
    set_prof(new_prs.get_prof());
    set_date(new_prs.get_Day(), new_prs.get_month(), new_prs.get_Year());
}

/*personal::personal(common& new_cmn, work& new_wrk): work(new_wrk, new_cmn){}

*/
char* personal::get_prof() const
{
    return prof;
}

/*date personal::get_DATE() const
{
    return DATE;
}*/

int personal::get_Day() const
{
    return DATE.getDay();
}

int personal::get_month() const
{
    return DATE.getMonth();
}

int personal::get_Year() const
{
    return DATE.getYear();
}

void personal::set_prof(char* n_pfor)
{
    delete[] prof;
    prof = new char[strlen(n_pfor)];
    strcpy_s(prof, strlen(n_pfor)+1, n_pfor);
}

void personal::set_date(date& n_DATE)
{
    DATE.setDay(n_DATE.getDay());
    DATE.setMonth(n_DATE.getMonth());
    DATE.setYear(n_DATE.getYear());
}


void personal::set_date(int n_Day, int n_Month, int n_Year)
{
    DATE.setDay(n_Day);
    DATE.setMonth(n_Month);
    DATE.setYear(n_Year);
}

personal& personal::operator=(personal& new_prs)
{
    if (this != &new_prs)
    {
        this->set_fam(new_prs.get_fam());
        this->set_name(new_prs.get_name());
        this->set_prof(new_prs.get_prof());
        this->set_date(new_prs.get_Day(), new_prs.get_month(), new_prs.get_Year());
    }
    return *this;
}

bool personal::operator==(const common& other) const
{
    return (strcmp(get_fam(), other.get_fam()) == 0 && strcmp(get_name(), other.get_name()) == 0);
}


void personal::show()
{
    cout<<setw(20)<<left<<get_fam();
    cout<<"|  ";
    cout<<setw(20)<<left<<get_name();
    cout<<"|  ";
    cout<<setw(20)<<left<<get_prof();
    cout<<"|  ";
    cout<<left<<get_Day()<<left<<" "<<left<<get_month()<<left<<" "<<left<<get_Year();
    cout<<endl;
}

istream& operator>>(istream& input, personal& new_prs)
{
    system("cls");
    do
    {
        try
        {
            cout<<"Введите порофессию: ";
            new_prs.set_prof(ErrorException::valid_char());
            break;
        }
        catch (const ErrorException& ex)
        {
            cerr << ex.what()<<endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
        }
    }
    while (true);
    
    system("cls");
    do
    {
        try
        {
            cout<<"Введите Дату через пробел 'DD MM YYYY': ";
            new_prs.set_date(ErrorException::valid_date());
            break;
        }
        catch (const ErrorException& ex)
        {
            cerr << ex.what()<<endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
        }
    }
    while (true);
    return input;
}

ostream& operator<<(ostream& output, personal& output_prs)
{
    output<<setw(20)<<left<<output_prs.get_fam();
    output<<"|  ";
    output<<setw(20)<<left<<output_prs.get_name();
    output<<"|  ";
    output<<setw(20)<<left<<output_prs.get_prof();
    output<<"|  ";
    output<<left<<output_prs.get_Day()<<left<<"."<<left<<output_prs.get_month()<<left<<"."<<left<<output_prs.get_Year();
    cout<<endl;
    return output;
}



