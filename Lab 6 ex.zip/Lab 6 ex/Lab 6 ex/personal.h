﻿#pragma once
#include "common.h"
#include "date.h"
#include "work.h"

class personal: public common
{
    char* prof;
    date DATE;
public:
    personal();
    ~personal();
    personal(date& n_DATE, char* n_prof);
    personal(common& new_cmn, personal& new_prs);
    //personal(common& new_cmn);
    char* get_prof() const;
    //date get_DATE() const;
    int get_Day() const;
    int get_month() const;
    int get_Year() const;
    void set_prof(char* n_pfor);
    void set_date(int n_Day, int n_Month, int n_Year);
    void set_date(date& n_DATE);

    personal& operator=(personal& new_prs);
    bool operator==(const common& other)const;
    void show();
    friend istream& operator>>(istream& input, personal& new_prs);
    friend ostream& operator<<(ostream& output, personal& output_prs);
    
};
