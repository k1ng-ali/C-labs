﻿#include "work.h"

#include <iomanip>

#include "functions.h"
#include <iostream>

using namespace std;

work::work()
{
    Dp = 0;
    salary = 0;
}

work::work(common& new_cmn, int n_dp, float n_slr):common(new_cmn)
{
    Dp = n_dp;
    salary = n_slr;
}

work::work(common& new_cmn): common(new_cmn){}

work::work(work& new_wrk, common& new_cmn):common(new_cmn)
{
    Dp = new_wrk.get_Dp();
    salary = new_wrk.get_slr();
}

work::~work()
{
    
}

int work::get_Dp() const
{
    return Dp;
}

float work::get_slr() const
{
    return salary;
}

void work::set_Dp(int n_dp)
{
    Dp = n_dp;
}

void work::set_slr(float n_slr)
{
    salary = n_slr;
}

void work::show()
{
    cout<<setw(20)<<left<<get_fam();
    cout<<"|  ";
    cout<<setw(20)<<left<<get_name();
    cout<<"|  ";
    cout<<setw(10)<<Dp;
    cout<<"|  ";
    cout<<setw(15)<<setprecision(2)<<salary<<endl;
}

istream& operator>>(istream& input, work& new_wrk) {
    system("cls");
    do {
        try {
            cout << "Введите номер отдела: ";
            new_wrk.Dp = ErrorException::valid_int();
            break;
        } catch (const ErrorException& ex) {
            cerr << ex.what() << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    } while (true);
    
    system("cls");
    do {
        
        try {
            cout << "Введите оклад: ";
            new_wrk.set_slr(ErrorException::valid_digit());
            break;
        } catch (const ErrorException& ex) {
            cerr << ex.what() << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    } while (true);

    return input;
}


bool work::operator==(const common& other) const
{
    return (strcmp(get_fam(), other.get_fam()) == 0 && strcmp(get_name(), other.get_name()) == 0);
}
