#include "ExeptError.h"
#include <string>

ExeptError::ExeptError(const char* msg): message(msg)
{
    
}

const char* ExeptError::what() const noexcept
{
    return message;
}

int ExeptError::valid_int()
{
    char num[4096];
    cout << "Введите число: ";
    cin>>num;
    if (!check_int(num))
    {
        system("cls");
        throw ExeptError("Ощибка: Ввод должен быть целым числом!");
    }
    return atoi(num);
}

bool ExeptError::check_int(const char* str)
{
    for (size_t i =0; i<strlen(str); ++i)
    {
        if (!isdigit(str[i]))
        {
            return false;
        }
    }
    if (atoi(str) < 0)
    {
        return false;
    }
    else
    {
        return true;
    }
}



