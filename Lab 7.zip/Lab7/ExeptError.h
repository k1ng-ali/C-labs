#pragma once
#include <iostream>
#include <stdexcept>
#include <cctype>
#include <cstring>

using namespace std;

class ExeptError: public exception
{
private:
    const char* message;
public:
    ExeptError(const char* msg);

    const char* what() const noexcept override;
    static int valid_int();

    static bool check_int(const char* str);
};
