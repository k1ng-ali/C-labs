#include "functions.h"
#include "worker.h"
#include <iomanip>
#include <iostream>
#include <locale>
#include <algorithm>
#include <fstream>

using namespace std;

/*ostream& operator<<(ostream& output, const worker& worker) {
    return worker.operator<<(output);
}*/

/*NEW*/

void add_obj(list<worker>& input)
{
    
    int choice;
    do
    {
        system("cls");
        print_submenu();
        choice_s(choice);
        worker* wrk = new worker;
        switch (choice)
        {
        case 1:
            cin>>*wrk;
            input.push_back(*wrk);
            break;
        case 2:
            do
            {
                list<worker>::iterator it = input.begin();
                int n;
                try
                {
                    cout << "Введите позицию, куда добавить объект: ";
                    n = ExeptError::valid_int();
                    cin >> *wrk;
                    if (n > input.size())
                    {
                        input.push_back(*wrk);
                    }
                    else
                    {
                        advance(it, n-1);
                        input.insert(it, *wrk);
                    }
                    break;
                }
                catch (const ExeptError& ex)
                {
                    cerr << ex.what() << endl;
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                }
                
            }
            while (true);
            break;
        case 3:
            cout << "Выход в главнюю меню"<<endl;
            system("pause");
            break;
        default:
            cout<<"Ощибка: введите число от 1 до 3 включительно!" << endl;
            system("pause");
            break;
        }
    }
    while (choice != 3);
    
}


void dell_obj(list<worker>& input)
{
    int choice;
    do
    {
        system("cls");
        print_submenu_dell();
        choice_s(choice);
        switch (choice)
        {
        case 1:
            system("cls");
            input.pop_front();
            cout<< "Удалено успешно!"<<endl;
            system("pause");
            system("cls");
            break;
        case 2:
            do
            {
                int n;
                try
                {
                    cout<<"Введите количество элементов для удаление: ";
                    n = ExeptError::valid_int();
                    if (n < input.size())
                    {
                        auto start = input.begin();
                        auto end = input.begin();
                        advance(end, n);
                        input.erase(start, end);
                    }
                    else
                    {
                        input.clear();
                    }
                    break;
                }
                catch (const ExeptError& ex)
                {
                    cerr << ex.what() << endl;
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                }
            }while (true);
            system("cls");
            cout<<"Удалено успешно!"<<endl;
            system("pause");
            system("cls");
            break;
        case 3:
            system("cls");
            cout << "Выход в главнюю меню"<<endl;
            system("pause");
            break;
        default:
            cout<<"Ощибка: введите число от 1 до 3 включительно!" << endl;
            system("pause");
        }
        
    }
    while (choice!=3);
}



int check_digit(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isdigit(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

int check_int(char* input)
{
    int i =  0;
    while (input[i])
    {
        if (input[i]!='.' && !isdigit(input[i]) && input[i] != ',' && input[i]!='-')
        {
            return 0;
        }
        if (input[i] == '.')
        {
            input[i] = ',';
        }
        i++;
    }
    return 1;
}

int check_str(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isalpha(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

void print_Heading()
{
    cout<<setw(37)<<left<<"Фамилия";
    cout<<"|  ";
    cout<<setw(33)<<left<<"Имя";
    cout<<"|  ";
    cout<<setw(26)<<left<<"Номер отдела";
    cout<<"  |";
    cout<<right<<setw(25)<<fixed<<"Оклад";
    cout<<endl;
    cout<<"========================================================================================================="<<endl;

}

void print_menu()
{
    cout << endl << "Выберите действие" << endl << endl;
    cout << "Добавить новый объект. . . . . . . . . . . . . . . . 1" << endl;
    cout << "Удалить объект из начала списка. . . . . . . . . . . 2" << endl;
    cout << "Распечатать информацию о работниках. . . . . . . . . 3" << endl;
    cout << "Сортировать данные по фамилию. . . . . . . . . . . . 4" << endl;
    cout << "Поиск работников по номеру отделу. . . . . . . . . . 5" << endl;
    cout << "Выход из программы . . . . . . . . . . . . . . . . . 6" << endl;
}

void print_submenu()
{
    cout << endl << "Выберите действие" << endl << endl;
    cout << "Добавить новей объект в концу списка . . . . . . . . 1" << endl;
    cout << "Добавить новый объект в N позицию. . . . . . . . . . 2" << endl;
    cout << "Выход в главный меню . . . . . . . . . . . . . . . . 3" << endl;
}

void print_submenu_dell()
{
    cout << endl << "Выберите действие" << endl << endl;
    cout << "Удалить первый объект из списка. . . . . . . . . . . 1" << endl;
    cout << "Удалить несколько объекть из начало списка . . . . . 2" << endl;
    cout << "Выход в главный меню . . . . . . . . . . . . . . . . 3" << endl;
}



void sort_by_fam(list<worker>& input)
{
    input.sort([](const worker& a, const worker& b)
    {
        return strcmp(a.get_fam(), b.get_fam()) < 0;
    });
}

void find_by_dp(list<worker>& input)
{
    int n;
    int k = 0;
    do
    {
        try
        {
            cout<<"Введите номер отдела для поиска: ";
            n = ExeptError::valid_int();
            break;
        }
        catch (const ExeptError& ex)
        {
            cerr << ex.what() << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    } while(true);

    print_Heading();
    for (auto it = input.begin(); it != input.end(); it++)
    {
        if (it->get_Dp() == n)
        {
            cout<< *it;
            k++;
        }
    }
    if(k==0)
    {
        cout<<"Работники по одтелу "<<n<<" не нащлось"<<endl<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k;
        cout<<endl;
    }
}



void choice_s(int& choise)
{
    do
    {
        char buff[4096];
        cout<<endl<<"Введите номер функции: ";
        cin>>buff;
        if (!check_digit(buff))
        {
            cout<<"Ощибка: введите целое число от 1 до 7 включительно!"<<endl;
            system("pause");
            system("cls");
            print_menu();
            continue;
        }
        else
        {
            choise = atoi(buff);
        }
        break;
    }
    while (true);
}

void print_data(list<worker>& input)
{
    print_Heading();
    int k = 0;
    for(auto it = input.begin(); it != input.end(); it++,k++)
    {
        cout << *it;
    }
    cout<<endl<<setw(40)<<left<<"Количество найденных записей";
    cout<<setw(20)<<fixed<<k;
    cout<<endl;
}

// ЧТЕНИЕ И ЗАПИСЬ ДАННЫЕ

void write_data(list<worker>& input, const string& filename)
{
    ofstream outputFile(filename);

    if (!outputFile)
    {
        cerr<<"Не удалось открыть файл для записи!"<<endl;
        return;
    }

    for (auto it = input.begin(); it != input.end(); it++)
    {
        outputFile<<it->get_fam()<<" ";
        outputFile<<it->get_name()<<" ";
        outputFile<<it->get_Dp()<<" ";
        outputFile<<it->get_Slr()<<" "<<endl;
    }

    outputFile.close();
    cout<<"Данные успещно записаны в файл: "<<filename<<endl;
}

void read_data(list<worker>& input, const string& filename)
{
    ifstream inputFile(filename);

    if (!inputFile)
    {
        cerr<<"Не удалось открыть файл для чтения!"<<endl;
        return;
    }

    while (!inputFile.eof())
    {
        man fio;
        int dp;
        double slr;
        char dp_buff[4096];
        char slr_buff[4096];
        char buffFam[4096];
        char buffName[4096];
        if (!(inputFile>>buffFam>>buffName>>dp_buff>>slr_buff))
        {
            if (inputFile.eof())
            {
                break; // Если конец файла достигнут, прерываем цикл
            }
            else {
                cerr << "Ошибка чтения данных из файла." << endl;
                return;
            }
        }
        check_int(slr_buff);
        dp = atoi(dp_buff);
        slr = atof(slr_buff);
        fio.set_fam(buffFam);
        fio.set_name(buffName);
        worker* wrk = new worker(fio, dp, slr);
        input.push_back(*wrk);
    }

    inputFile.close();
}

