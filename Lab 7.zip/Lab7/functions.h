#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <list>

#include "ExeptError.h"
#include "worker.h"

using namespace std;

//ostream& operator<<(ostream& output, const worker& worker);
void add_obj(list<worker>& input);
void dell_obj(list<worker>& input);

int check_digit(const char* input);
int check_int(char* input);
int check_str(const char* input);
void print_Heading();
void print_menu();
void print_submenu();
void print_submenu_dell();

void sort_by_fam(list<worker>& input);
void find_by_dp(list<worker>& input);

void choice_s(int& choise);
void print_data(list<worker>& input);


void write_data(list<worker>& input, const string& filename);
void read_data(list<worker>& input, const string& filename);


#endif // FUNCTIONS_H