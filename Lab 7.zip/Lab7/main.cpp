#include "functions.h"
#include "worker.h"
#include "man.h"
#include <locale.h>
#include <iostream>
#include <list>

using namespace std;

int main()
{
    // Устанавливаем локаль на русскую для UTF-8
    setlocale(LC_ALL, "Russian_Russia.65001");

    // Настраиваем вывод wcout на использование локали
    std::wcout.imbue(std::locale("Russian_Russia.65001"));
    list<worker> MWor;
    int choice;
    read_data(MWor,"data.txt");

    do
    {
        system("cls");
        print_menu();
        choice_s(choice);

        switch (choice)
        {
        case 1:
            system("cls");
            add_obj(MWor);
            system("cls");
            break;
        case 2:
            system("cls");
            dell_obj(MWor);
            system("cls");
            break;
        case 3:
            system("cls");
            print_data(MWor);
            system("pause");
            system("cls");
            break;
        case 4:
            system("cls");
            sort_by_fam(MWor);
            cout<<"Успешно отсортирован!"<<endl;
            system("pause");
            system("cls");
            break;
        case 5:
            system("cls");
            find_by_dp(MWor);
            system("pause");
            system("cls");
            break;
        case 6:
            cout<<"Выход из программы..."<<endl;
            system("pause");
            break;
        default:
            cout << "Ощибка: введите число от 1 до 5 включительно!" << endl;
            system("pause");    
        }
        
    }while (choice != 6);

    write_data(MWor, "data.txt");

    MWor.clear();
    return 0;
}