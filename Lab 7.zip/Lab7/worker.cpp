#include "worker.h"

#include <iomanip>

#include "functions.h"
#include <iostream>

#include  "man.h"

#include <string.h>
#include <string>
using namespace std;

worker::worker()
{
    departament = 0;
    salary = 0;
}

worker::~worker()
{
    
}

worker::worker(man& FIO_new, int dp, float slr)
{
    FIO.set_fam(FIO_new.get_fam());
    FIO.set_name(FIO_new.get_name());
    departament = dp;
    salary = slr;
}

char* worker::get_fam() const
{
    return FIO.get_fam();
}

char* worker::get_name() const
{
    return FIO.get_name();
}

int worker::get_Dp() const
{
    return departament;
}

float worker::get_Slr() const
{
    return salary;
}


void worker::set_FIO(man& FIO_new)
{
    FIO.set_fam(FIO_new.get_fam());
    FIO.set_name(FIO_new.get_name());
}

void worker::set_Dp(int dp)
{
    departament = dp;
}

void worker::set_Slr(float slr)
{
    salary = slr;
}

bool worker::operator==(const man& FIO_other) const
{

    
    return 1;
}



istream& operator>>(istream& input, worker& worker)
{
    cin>>worker.FIO;
    do
    {
        char buff[4096];
        cout<<"Фамилия: "<<worker.get_fam()<<endl;
        cout<<"Имя: "<<worker.get_name()<<endl;
        cout<<"Введите номер отдела: ";
        input>>buff;
        if (!check_digit(buff))
        {
            cout<<"Ощибка: введитецелое число!"<<endl;
            system("pause");
            system("cls");
            continue;
        }
        else
        {
            if((atoi(buff))<=0)
            {
                cout<<"Ощибка: Введите целое число больше 0!"<<endl;
                system("pause");
                system("cls");
                continue;
            }
            else
            {
                worker.set_Dp(atoi(buff));
            }
        }
        break;
    }while(true);
    system("cls");

    do
    {
        char buff[4096];
        cout<<"Фамилия: "<<worker.get_fam()<<endl;
        cout<<"Имя: "<<worker.get_name()<<endl;
        cout<<"Отдел: "<<worker.get_Dp()<<endl;
        cout<<"Введите оклад: ";
        input>>buff;
        if(!check_int(buff))
        {
            cout<<"Ощибка: Введите число!"<<endl;
            system("pause");
            system("cls");
            continue;
        }
        else
        {
            if ((stod(buff))<0)
            {
                cout<<"Ощибка: Введите число больще 0!"<<endl;
                system("pause");
                system("cls");
            }
            else
            {
                worker.set_Slr(stod(buff));
            }
        }
        break;
    }
    while (true);
    return input;
}

ostream& operator<<(ostream& output, worker& worker) 
{
    output<<setw(30)<<left<<worker.get_fam();
    output<<"|  ";
    output<<setw(30)<<left<<worker.get_name();
    output<<"|  ";
    output<<setw(15)<<right<<worker.get_Dp();
    output<<"  |";
    output<<setw(20)<<fixed<<setprecision(2)<<worker.get_Slr();
    output<<endl;
    return output;
}












