#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale>
#include "Salary.h"

int check_str(const char* input)
{
    int i =0;
    while (input[i])
    {
        if (isdigit(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

int check_digit(const char* input)
{
    int i =0;
    while (input[i])
    {
        if (!isdigit(input[i]) && input[i] != '.' && input[i] != '-')
        {
            return 0;
        }
        i++;
    }
    return 1;
}

void addSalary(Salary* salr, int* n) {
    char buff[100];
    printf("Введите Фамилию работника: ");
    do
    {
        scanf("%s", buff);
        if (!check_str(buff))
        {
            printf("Ощибка: Некорректнй ввод! \n");
        }
        else
        {
            salr[*n].fam = new char[strlen(buff)+1];
            strcpy(salr[*n].fam, buff);
            break;
        }
    } while (1);
    
    
    printf("Введите имя работника: ");
    do
    {
        scanf("%s", buff);
        if (!check_str(buff))
        {
            printf("Ощибка: Некорректнй ввод! \n");
        }
        else
        {
            salr[*n].name = new char[strlen(buff)+1];
            strcpy(salr[*n].name, buff);
            break;
        }
    } while (1);
    

    printf("Введите Отдел работы: ");
    do
    {
        scanf("%s", buff);
        if (!check_digit(buff))
        {
            printf("Ощибка: Некорректный ввод \n");
        }
        else
        {
            salr[*n].departament = atoi(buff);
            break;
        }
    }
    while (1);

    printf("Введите оклад: ");
    do
    {
        scanf("%s", buff);
        if (!check_digit(buff))
        {
            printf("Ощибка: Некорректный ввод \n");
        }
        else
        {
            salr[*n].salary = atof(buff);
            break;
        }
    }
    while (1);
    (*n)++;
}

void printSalary(Salary* salr, int j, int k) {
    printf("\n %-30s %s %-30s %s %-15s %s %-20s", "Фамилия", "|  ", "Имя", "|  ", "Отдел", "|  ", "Оклад");
    printf("\n %-30s %-34s %-19s %-25s",  " ","|  ","|  ","|  ");
    printf("\n=======================================================================================================");
    double summ_slr= 0;
    for (int i = j; i < k; i++) {
        printf("\n %-30s %s %-30s %s %-15d %s %-20.2lf",
            salr[i].fam,"|  ", salr[i].name,"|  ", salr[i].departament,"|  ", salr[i].salary);
        summ_slr += salr[i].salary;
    }
    printf("\n=======================================================================================================");
    printf("\n%-45s%-45d", "Количество Работников:", (k-j));
    printf("\n%-45s%-45.2lf", "Общий оклад:", summ_slr);
    printf("\n\n");
}

void find_Slr_Byname(Salary* salr, int n, char* targetLastName, char* targetFirstName) {
    Salary* target_salary = new Salary[n];
    int k = 0;
    for (int i = 0; i < n; i++)
    {
        if (strcmp(salr[i].fam, targetLastName) == 0 && strcmp(salr[i].name, targetFirstName) == 0)
        {
            target_salary[k].fam = new char[strlen(salr[i].fam)+1];
            target_salary[k].name = new char[strlen(salr[i].name)+1];
            strcpy(target_salary[k].fam, salr[i].fam);
            strcpy(target_salary[k].name, salr[i].name);
            target_salary[k].departament = salr[i].departament;
            target_salary[k].salary = salr[i].salary;
            (k)++;
        }
    }
    int i = 0;
    int j = 0;
    printf("%s %s %s", "Результат поиска по имени ", targetLastName, targetFirstName);
    if (k>20)
    {
        int choice = 0;
        do
        {
            j += 20;
            system("cls");
            printf("%s %d","Количество записей в данных:", k);
            printf("\n\nВыберите действие:\n\n");
            printf("%s %d %s %d %s","Вывести данные от ", i, " до ", (j), ". . . . . . . . . . . 1");
            printf("\nВыход. . . . . . . . . . . . . . . . . . . . . . . . 2");
            if (scanf("%d", &choice) != 1)
            {
                while (getchar() != '\n');
                system("cls");
                printf("Неверный ввод. Пожалйста, введите число!\n");
                system("pause");
                continue;
            }
            switch (choice)
            {
            case 1:
                if (k>j)
                {
                    system("cls");
                    printf("%s %s %s", "Результат поиска по имени ", targetLastName, targetFirstName);
                    printSalary(target_salary, i, j);
                    printf("%s %d %s %d %s", "\nВыведено данные от ", i, " до ", j, "\n");
                    system("pause");
                    i += 20;
                }
                else
                {
                    j = k;
                    system("cls");
                    printf("%s %s %s", "Результат поиска по имени ", targetLastName, targetFirstName);
                    printSalary(target_salary, i, j);
                    printf("%s %d %s %d %s", "\nВыведено данные от ", i, " до ", k, "\n");
                    system("pause");
                    break;
                }
                break;
            default:
                system("cls");
                printf("Неверный ввод. Пожалуйста, введите число от 1 до 2 включительно.\n");
                system("pause");
                system("cls");
            }
 
        }
        while (choice != 2 && j != k);
    }
    else
    {
        printf("%s %s %s", "Результат поиска по имени ", targetLastName, targetFirstName);
        printSalary(target_salary, i, k);
        printf("%s %d %s %d %s", "\nВыведено данные от ", i, " до ", k, "\n");
        system("pause");
        system("cls");        
    }
    for (int i =0; i<k; i++)
    {
        delete[] target_salary[i].fam;
        delete[] target_salary[i].name;
    }
}

void find_Slr_Bydep(Salary* salr, int n, int targetDep) {
    Salary* target_salary = new Salary[n];
    int k = 0;
    for (int i = 0; i < n; i++) {
        if (salr[i].departament == targetDep)
        {
            target_salary[k].fam = new char[strlen(salr[i].fam)+1];
            target_salary[k].name = new char[strlen(salr[i].name)+1];
            strcpy(target_salary[k].fam, salr[i].fam);
            strcpy(target_salary[k].name, salr[i].name);
            target_salary[k].departament = salr[i].departament;
            target_salary[k].salary = salr[i].salary;
            (k)++;
    
        }
    }
    printf("%s %d","Результат поиска по отделу № ", targetDep);
    printf("\n\n");
     int i = 0;
    int j = 0;
    printf("%s %d","Результат поиска по отделу № ", targetDep);
    if (k>20)
    {
        int choice = 0;
        do
        {
            j += 20;
            system("cls");
            printf("%s %d","Количество записей в данных:", k);
            printf("\n\nВыберите действие:\n\n");
            printf("%s %d %s %d %s","Вывести данные от ", i, " до ", (j), ". . . . . . . . . . . 1");
            printf("\nВыход. . . . . . . . . . . . . . . . . . . . . . . . 2");
            if (scanf("%d", &choice) != 1)
            {
                while (getchar() != '\n');
                system("cls");
                printf("Неверный ввод. Пожалйста, введите число!\n");
                system("pause");
                continue;
            }
            switch (choice)
            {
            case 1:
                if (k>j)
                {
                    system("cls");
                    printf("%s %d","Результат поиска по отделу № ", targetDep);
                    printSalary(target_salary, i, j);
                    printf("%s %d %s %d %s", "\nВыведено данные от ", i, " до ", j, "\n");
                    system("pause");
                    i += 20;
                }
                else
                {
                    j = k;
                    system("cls");
                    printf("%s %d","Результат поиска по отделу № ", targetDep);
                    printSalary(target_salary, i, j);
                    printf("%s %d %s %d %s", "\nВыведено данные от ", i, " до ", k, "\n");
                    system("pause");
                    break;
                }
                break;
            default:
                system("cls");
                printf("Неверный ввод. Пожалуйста, введите число от 1 до 5 включительно.\n");
                system("pause");
                system("cls");
            }
 
        }
        while (choice != 2 && j != k);
    }
    else
    {
        printf("%s %d","Результат поиска по отделу № ", targetDep);
        printSalary(target_salary, i, k);
        printf("%s %d %s %d %s", "\nВыведено данные от ", i, " до ", k, "\n");
        system("pause");
        system("cls");        
    }    for (int i =0; i<k; i++)
    {
        delete[] target_salary[i].fam;
        delete[] target_salary[i].name;
    }

}


void saveDataToFile(Salary* salr, int* n, int* pre_size) {
    FILE* file = fopen("Salary_data.txt", "a");
    if (file == NULL)
    {
        printf("Ошибка открытия файла для записи.\n");
        return;
    }
    for (int i = *pre_size; i < *n; i++)
    {
        fprintf(file, "%s %s %d %.2lf\n",
            salr[i].fam, salr[i].name, salr[i].departament, salr[i].salary);
    }
    fclose(file); 
 }

void loadDataFromFile(Salary* salr, int* n, int data_size) {
    FILE* file = fopen("Salary_data.txt", "r");
    if (file == NULL) {
        printf("Файл не найден. Введите данные с клавиатуры.\n");
        return;
    }

    // Выделение памяти перед входом в цикл
    char buff1[80];
    char buff2[80];

    char line[256];  // Предполагаем максимальную длину строки данных
    while (fgets(line, sizeof(line), file) != NULL) {
        sscanf(line,"%s %s %d %lf",
            buff1, buff2, &salr[*n].departament, &salr[*n].salary);
        salr[*n].fam = new char[strlen(buff1)+1];
        salr[*n].name = new char[strlen(buff2)+1];
        strcpy(salr[*n].fam, buff1);
        strcpy(salr[*n].name, buff2);
        (*n)++;
        if (*n >= data_size)
        {
            printf("%s %d %s","Выделенный память заполнен. Загружено ", data_size, "объектов");
            system("pause");
            break;
        }
    }

    fclose(file);
}