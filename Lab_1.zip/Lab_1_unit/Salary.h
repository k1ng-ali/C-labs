#pragma once

typedef struct
{
    char* fam;
    char* name;
    int departament;
    double salary;
} Salary;

int check_str(const char* input);
int check_digit(const char* input);
void addSalary(Salary* salr, int* n);
void printSalary(Salary* salr, int i, int k);
void find_Slr_Byname(Salary* salr, int n,  char* targetLastName, char* targetFirstName);
void find_Slr_Bydep(Salary* salr, int n, int targetDep);
void saveDataToFile(Salary* salr, int* n, int* pre_size);
void loadDataFromFile(Salary* salr, int* n, int data_size);
