#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "Salary.h"

int main()
{
    int choice;
    int choice_1;
    int n = 0;
    int data_size = 100;
    system("chcp 1251");
    Salary* salr = new Salary[data_size];
    loadDataFromFile(salr, &n, data_size);
    int pre_size = n;
    setlocale(LC_ALL, "RUS");

    do {
        printf("\nВыберите действие:\n\n");
        printf("Добавить новые данные. . . . . . . . . . . . . . . . 1\n");
        printf("Распечатать информацию работниках. . . . . . . . . . 2\n");
        printf("Поиск по ФИО работника . . . . . . . . . . . . . . . 3\n");
        printf("Поиск по отделу. . . . . . . . . . . . . . . . . . . 4\n");
        printf("Выйти из программы . . . . . . . . . . . . . . . . . 5\n\n");
        printf("Введите номер функции: ");

        if (scanf("%d", &choice) != 1)
        {
            while (getchar() != '\n');
            system("cls");
            printf("Неверный ввод. Пожалйста, введите число!\n");
            system("pause");
            continue;
        }
        int targetDep = 0;
        int i = 0;
        int k = 0;
        
        switch (choice) {
        case 1:
            if (n>=data_size)
            {
                do
                {
                    system("cls");
                    printf("%s %d %s", "Выделенный память заполнен. Выделено память для ", data_size, " объектов\n");
                    printf("\nВыберите дейстиве\n\n");
                    printf("Рассширить память. . . . . . . . . . . . . . . . . . 1\n");
                    printf("Пропустить . . . . . . . . . . . . . . . . . . . . . 2\n");
                    if (scanf("%d", &choice) != 1)
                    {
                        while (getchar()!='\n');
                        system("cls");
                        printf("Неверный ввод. Пожалйста, введите число!\n");
                        system("pause");
                        continue;
                    }
                    switch (choice)
                    {
                    case 1:
                        char buff[80];
                        printf("Введите число для выделения памяти для новых объектов: ");
                        do
                        {
                            scanf("%s", buff);
                            if (!check_digit(buff) && atoi(buff)>100)
                            {
                                printf("\nОщибка! введите число от 0 до 100\n");
                            }
                            else
                            {
                                data_size += atoi(buff);
                                Salary* salr = new Salary[data_size];
                                break;
                            }
                        }while (1);
                        system("cls");
                        printf("%s %d %s","\nУспешно выделено память для ", atoi(buff), " новых объектов\n\n");
                        addSalary(salr, &n);
                        choice = 2;
                        break;
                    default:
                        system("cls");
                        printf("Неверный ввод. Пожалуйста, введите цифру 1 или 2\n");
                    }
                } while (choice != 2);
            }
            else
            {
                addSalary(salr, &n);
                printf("\nДобавлено Успешно!\n\n");
                system("pause");
                system("cls");
            }
            break;
        case 2:
            system("cls");
            if(n>20)
            {
                i = 0;
                k = 0;
                do
                {
                    k += 20;
                    system("cls");
                    printf("%s %d","Количество записей в данных:", n);
                    printf("\n\nВыберите действие:\n\n");
                    printf("%s %d %s %d %s","Вывести данные от ", i, " до ", (k), ". . . . . . . . . . . . 1");
                    printf("\nВыход. . . . . . . . . . . . . . . . . . . . . . . . 2\n");
                    if (scanf("%d", &choice) != 1)
                    {
                        while (getchar() != '\n');
                        system("cls");
                        printf("Неверный ввод. Пожалйста, введите число!\n");
                        system("pause");
                        continue;
                    }
                    
                    switch (choice)
                    {
                    case 1:
                        if (n>(k))
                        {
                            system("cls");
                            printSalary(salr, i, k);
                            printf("%s %d %s %d %s", "\nВыведено данные от ", i, " до ", k, "\n");
                            system("pause");
                            i += 20;
                        }
                        else
                        {
                            k = n;
                            system("cls");
                            printSalary(salr, i, k);
                            printf("%s %d %s %d %s", "\nВыведено данные от ", i, " до ", k, "\n");
                            system("pause");
                            break;
                        }
                        break;
                    default:
                        system("cls");
                        printf("Неверный ввод. Пожалуйста, введите число от 1 до 5 включительно.\n");
                        system("pause");
                        system("cls");
                    }
                }while (choice != 2 && k != n);
                system("cls");
            }
            else
            {
                printf("%s %d %s %d %s", "\nВыведено данные от ", i, " до ", n, "\n");
                printSalary(salr, i, n);
                system("pause");
                system("cls");
                        
            }
            break;
        case 3:
            system("cls");
            char buff1[50];
            char buff2[50];
            char targetLastName[50];
            char targetFirstName[50];
            printf("\nВведите фамилию работника для поиска: ");
            do
            {
                scanf("%s", buff1);
                if (!check_str(buff1))
                {
                    printf("Ощибка: Некорректнй ввод! \n");
                }
                else
                {
                    strcpy(targetLastName, buff1);
                    break;
                }
            } while (1);
            printf("\nВведите Имя работника для поиска: ");
            do
            {
                scanf("%s", buff2);
                if (!check_str(buff2))
                {
                    printf("Ощибка: Некорректнй ввод! \n");
                }
                else
                {
                    strcpy(targetFirstName, buff2);
                    break;
                }
            } while (1);
            find_Slr_Byname(salr, n,  targetLastName, targetFirstName);
            system("pause");
            system("cls");
            break;
        case 4:
            system("cls");
            printf("\nВведите номер отдела: ");
            do
            {
                char buff[80];
                scanf("%s", buff);
                if (!check_digit(buff))
                {
                    printf("Ощибка: введите число!");
                }
                else
                {
                    targetDep = atoi(buff);
                    break;
                }
            } while (1);
            find_Slr_Bydep(salr, n, targetDep);
            system("pause");
            system("cls");
            break;
        case 5:
            system("cls");
            printf("Выход из программы.\n");
            system("cls");
            break;
        default:
            system("cls");
            printf("Неверный ввод. Пожалуйста, введите число от 1 до 5 включительно.\n");
            system("pause");
            system("cls");
        }

    } while (choice != 5);
    saveDataToFile(salr, &n, &pre_size);
    // Освобождение выделенной памяти
    for (int i = 0; i < pre_size; i++) {
        delete[] salr[i].fam;
        delete[] salr[i].name;
    }
    return 0;
}

