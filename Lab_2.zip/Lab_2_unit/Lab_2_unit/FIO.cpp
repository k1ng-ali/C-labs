// В файле FIO.cpp

#include "FIO.h"
#include <iostream>
#include <cstring>
#include "functions.h"

using namespace std;

FIO::FIO() {
    fam = new char[4096];
    strcpy_s(fam, 4096, " ");
    name = new char[4096];
    strcpy_s(name, 4096, " ");
}

FIO::~FIO() {
    delete[] fam;
    delete[] name;
}

void FIO::init_FIO() {
    char buff[4096];
    do
    {
        cout<<"Введите фамилию работника: ";
        cin>>buff;
        if (!check_str(buff))
        {
            cout<<"Ощибка: Фамилия должно соддержать только букву!"<<endl;
            system("pause");
            system("cls");
        }
        else
        {
            setFam(buff);
            break;
        }
    }while (true);
    system("cls");
    do
    {
        cout<<"Фамилия: "<<getFam()<<endl;
        cout<<"Введите имя работника: ";
        cin>>buff;
        if (!check_str(buff))
        {
            cout<<"Ощибка: Имя должно соддержать только букву!"<<endl;
            system("pause");
            system("cls");
        }
        else
        {
            name = new char[strlen(buff)+1];
            strcpy_s(name,strlen(buff)+1,buff);
            break;
        }
    }while (true);
    cout<<endl;
}

char* FIO::getFam() const
{
    return fam;
}

char* FIO::getName() const
{
    return name;
}


void FIO::setFam(const char* newFam)
{
    delete[] fam;
    fam = new char[strlen(newFam) + 1]; 
    strcpy_s(fam,strlen(newFam)+1, newFam);
}

void FIO::setName(const char* newName)
{
    delete[] name;
    name = new char[strlen(newName)+1];
    strcpy_s(name, strlen(newName)+1, newName);
}
