#include "worker.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

void print_menu()
{
    cout << endl << "Выберите действие" << endl << endl;
    cout << "Добавить новые данные. . . . . . . . . . . . . . . . 1" << endl;
    cout << "Распечатать информацию о работниках. . . . . . . . . 2" << endl;
    cout << "Поиск по ФИО работника . . . . . . . . . . . . . . . 3" << endl;
    cout << "Поиск по отделу. . . . . . . . . . . . . . . . . . . 4" << endl;
    cout << "Выход из программы . . . . . . . . . . . . . . . . . 5" << endl;
}



int check_digit(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isdigit(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

int check_int(char* input)
{
    int i = 0;
    while (input[i])
    {
        if (input[i]!='.' && !isdigit(input[i]) && input[i]!='-')
        {
            return 0;
        }
        if (input[i]=='.')
        {
            input[i] = ',';
        }
        i++;
    }
    return 1;
}

int check_str(const char* input)
{
    int i = 0;
    while (input[i])
    {
        if (!isalpha(input[i]))
        {
            return 0;
        }
        i++;
    }
    return 1;
}

void init_data(worker* info[], int* n)
{
    FIO chel;
    int dp;
    double slr;
    chel.init_FIO();
    system("cls");
    do
    {
        char buff[50];
        cout<<"Фамилия: "<<chel.getFam()<<endl;
        cout<<"Имя: "<<chel.getName()<<endl;
        cout<<"Введите номер отдела: ";
        cin>>buff;
        if (!check_digit(buff))
        {
            cout<<"Ощибка: введите целое число!"<<endl;
            system("pause");
            system("cls");
            continue;
        }
        else
        {
            if((atoi(buff))<=0)
            {
                cout<<"Ощибка: Введите целое число больше 0!"<<endl;
                system("pause");
                system("cls");
                continue;
            }
            else
            {
                dp = atoi(buff);
            }
        }
        break;
    }while(true);
    system("cls");
    do
    {
        char buff[4096];
        cout<<"Фамилия: "<<chel.getFam()<<endl;
        cout<<"Имя: "<<chel.getName()<<endl;
        cout<<"Отдел: "<<dp<<endl;
        cout<<"Введите оклад: ";
        cin>>buff;
        if (!check_int(buff))
        {
            cout<<"Ощибка: Введите число!"<<endl;
            system("pause");
            system("cls");
            continue;
        }
        else
        {
            if ((stod(buff))<=0)
            {
                cout<<"Ощибка: Введите число больще 0!"<<endl;
                system("pause");
                system("cls");
            }
            else
            {
                slr = std::stod(buff);
            }
        }
        break;
    }while (true);
    info[*n]->init_worker(chel, dp, slr);
    (*n)++;
}

void print_data(worker* info[], int n)
{
    cout<<setw(30)<<left<<"Фамилия";
    cout<<"|  ";
    cout<<setw(30)<<left<<"Имя";
    cout<<"|  ";
    cout<<setw(15)<<left<<"Номер отдела";
    cout<<"  |";
    cout<<setw(20)<<fixed<<"Оклад";
    cout<<endl;
    cout<<"======================================================================================================="<<endl;
    int k = 0;
    for(int i =0;i<n;i++,k++)
    {
        info[i]->print_worker();
    }
    cout<<endl<<setw(40)<<left<<"Количество найденных записей";
    cout<<setw(20)<<fixed<<k;
    cout<<endl;
}

void findByName(worker* info[], int n, char* targetFam, char* targetName)
{
    system("cls");
    bool f = false;

    cout<<"Поиск по имени: "<<targetFam<<"  "<<targetName<<endl<<endl;
    cout<<setw(30)<<left<<"Фамилия";
    cout<<"|  ";
    cout<<setw(30)<<left<<"Имя";
    cout<<"|  ";
    cout<<setw(15)<<left<<"Номер отдела";
    cout<<"  |";
    cout<<setw(20)<<fixed<<"Оклад";
    cout<<endl;
    cout<<"======================================================================================================="<<endl;
    int k = 0;
    for (int i =0; i<n;i++)
    {
        if (info[i]->findByName(targetFam, targetName))
        {
            info[i]->print_worker();
            k++;
            f = true;
        }
    }
    if (!f)
    {
        cout<<"Работник по имени "<<targetFam<<" "<<targetName<<" не найдено!"<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k;
        cout<<endl;
    }
    
}

void write_data(worker* info[], int n, const string& filename)
{
    ofstream outputFile(filename);

    if (!outputFile)
    {
        cerr<<"Не удалось открыть файл для записи!"<<endl;
        return;
    }

    for (int i = 0; i<n;i++)
    {
        outputFile<<info[i]->getFam()<<" ";
        outputFile<<info[i]->getName()<<" ";
        outputFile<<info[i]->get_department()<<" ";
        outputFile<<info[i]->getSlr()<<" "<<endl;
    }

    outputFile.close();
    cout<<"Данные успещно записаны в файл: "<<filename<<endl;
}

void read_data(worker* info[], int& n, const string& filename, int N)
{
    ifstream inputFile(filename);

    if (!inputFile)
    {
        cerr<<"Не удалось открыть файл для чтения!"<<endl;
        return;
    }

    while (!inputFile.eof())
    {
        if ((n)>=N)
        {
            cout<<"Перевышен максимальный размер массива!"<<endl;
            system("pause");
            break;
        }
        info[n] = new worker;
        FIO fio;
        int dp;
        double slr;
        char dp_buff[4096];
        char slr_buff[4096];
        char buffFam[4096];
        char buffName[4096];
        if (!(inputFile>>buffFam>>buffName>>dp_buff>>slr_buff))
        {
            if (inputFile.eof())
            {
                break; // Если конец файла достигнут, прерываем цикл
            }
            else {
                cerr << "Ошибка чтения данных из файла." << endl;
                return;
            }
        }
        dp = atoi(dp_buff);
        slr = atof(slr_buff);
        fio.setFam(buffFam);
        fio.setName(buffName);
        
        info[n]->init_worker(fio, dp, slr);
        (n)++;
    }

    inputFile.close();
}
