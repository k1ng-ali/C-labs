#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include "worker.h"
#include <fstream>
using namespace std;

void print_menu();
int check_digit(const char* input);
int check_int(const char* input);
int check_str(const char* input);
void init_data(worker* info[], int* n);
void print_data(worker* info[], int n);
void findByName(worker* info[], int n, char* targetFam, char* targetName);
void read_data(worker* info[], int& n, const string& filename, int N);
void write_data(worker* info[], int n, const string& filename);

#endif // FUNCTIONS_Hs
