#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "worker.h"
#include "functions.h"

using namespace std;

int main() {
    setlocale(LC_ALL, "RUS");
    const int N = 100;
    int n = 0;
    int choice;
    worker* M[N]; // Массив указателей на объекты класса worker

    read_data(M, n, "data.txt", N);
    
    do {
        system("cls");
        print_menu();
        
        do
        {
            char buff[4096];
            cout << endl << "Введите номер функции: ";
            cin>>buff;
            if (!check_digit(buff))
            {
                cout<<"Ощибка: введите целое число от 1 до 5 включительно!"<<endl;
                system("pause");
                system("cls");
                print_menu();
                continue;
            }
            else
            {
                choice = atoi(buff);
                
            }
            break;
        }while(true);

        switch (choice) {
        case 1:
            system("cls");
            if (n<N)
            {
                M[n] = new worker;
                init_data(M,&n);
            }
            else
            {
                cout<<"Перевышен максимальный размер массива!"<<endl;
            }
            cout<<"Успещно добавлено!"<<endl;
            system("pause");
            system("cls");
            break;
        case 2:
            system("cls");
            print_data(M,n);
            system("pause");
            system("cls");
            break;
        case 3:
            system("cls");
            char buff1[4096];
            char targetFam[4096];
            char targetName[4096];
            do
            {
                cout<<"Введите фамилию работника для поиска: ";
                cin>>buff1;
                if (!check_str(buff1))
                {
                    cout<<"Ощибка: Некорректный ввод!"<<endl;
                    system("pause");
                    system("cls");
                }
                else
                {
                    strcpy_s(targetFam,strlen(buff1)+1,buff1);
                    break;
                }
            }while (true);
            system("cls");
            do
            {
                cout<<"Фамилия: "<<targetFam<<endl;
                cout<<"Введите Имя работника для поиска: ";
                cin>>buff1;
                if (!check_str(buff1))
                {
                    cout<<"Ощибка: некорректный ввод!"<<endl;
                    system("pause");
                    system("cls");
                }
                else
                {
                    strcpy_s(targetName,strlen(buff1)+1,buff1);
                    break;
                }
            }
            while (true);

            findByName(M,n,targetFam,targetName);
            system("pause");
            system("cls");
            break;
        case 4:
            system("cls");
            int targetDp;
            do
            {
                char buff[4096];
                cout<<"Введите номер отдела для поиска: ";
                cin>>buff;
                if (!check_digit(buff))
                {
                    cout<<"Ощибка: введите число!"<<endl;
                    system("pause");
                    system("cls");
                    continue;
                }
                else
                {
                    if ((atoi(buff)<=0))
                    {
                        cout<<"Ощибка: Введите число больше 0!"<<endl;
                        system("pause");
                        system("cls");
                        continue;
                    }
                    else
                    {
                        targetDp = atoi(buff);
                    }
                }
                break;
            }while(true);
            findByDep(M,n,targetDp);
            system("pause");
            system("cls");
            break;
        case 5:
            system("cls");
            cout<<"Выход из программы."<<endl;
            break;
        default:
            cout << "Ощибка: введите число от 1 до 5 включительно!" << endl;
            system("pause");
        }
    } while (choice != 5);

    write_data(M, n, "data.txt");
    
    // Освобождаем память, выделенную под объекты класса worker
    for (int i = 0; i < n; i++) {
        delete M[i];
    }

    system("pause");
    return 0;
}
