#include "worker.h"
#include "FIO.h" 

#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

worker::worker(int dp, double slr)
{
    department = dp;
    salary = slr;
}

worker::~worker() {
}

void worker::init_worker(FIO& fname, int dp, double slr) {
    name.setName(fname.getName());
    name.setFam(fname.getFam());
    department = dp;
    salary = slr;
}

void worker::print_worker() {
    cout<<setw(30)<<left<<name.getFam();
    cout<<"|  ";
    cout<<setw(30)<<left<<name.getName();
    cout<<"|  ";
    cout<<setw(15)<<right<<get_department();
    cout<<"  |";
    cout<<setw(20)<<fixed<<setprecision(2)<<getSlr();
    cout<<endl;
}

bool worker::findByName(const string& _fam, const string& _name)const
{
    return (name.getFam() == _fam && name.getName() == _name);
}

void findByDep(worker* workers[], int size, int dep)
{
    system("cls");
    cout<<"Поиск по отделу: "<<dep<<endl<<endl;
    cout<<setw(30)<<left<<"Фамилия";
    cout<<"|  ";
    cout<<setw(30)<<left<<"Имя";
    cout<<"|  ";
    cout<<setw(15)<<left<<"Номер отдела";
    cout<<"  |";
    cout<<setw(20)<<fixed<<"Оклад";
    cout<<endl;
    cout<<"======================================================================================================="<<endl;
    int k = 0;
    for (int i = 0; i<size; ++i)
    {
        if (workers[i]->get_department() == dep)
        {
            cout<<setw(30)<<left<<workers[i]->name.getFam();
            cout<<"|  ";
            cout<<setw(30)<<left<<workers[i]->name.getName();
            cout<<"|  ";
            cout<<setw(15)<<right<<workers[i]->get_department();
            cout<<"  |";
            cout<<setw(20)<<fixed<<setprecision(2)<<workers[i]->getSlr();
            cout<<endl;
            k++;
        }
    }
    if (k==0)
    {
        cout<<"Работников по отделу "<<dep<<" не найдено"<<endl;
    }
    else
    {
        cout<<endl;
        cout<<setw(40)<<left<<"Количество найденных записей";
        cout<<setw(20)<<fixed<<k;
        cout<<endl;
    }
}

int worker::get_department() {
    return department;
}

char* worker::getFam() const
{
    return name.getFam();
}

char* worker::getName() const
{
    return name.getName();
}

double worker::getSlr() const
{
    return salary;
}

