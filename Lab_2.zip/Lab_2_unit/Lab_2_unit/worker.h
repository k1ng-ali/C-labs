#ifndef WORKER_H
#define WORKER_H

#include <xstring>

#include "FIO.h"

class worker {
    int department;
    FIO name;
    double salary;
public:
    worker(int dp = 0, double slr = 0);
    ~worker();
    void init_worker(FIO& fname, int dp, double slr);
    void print_worker();
    int get_department();
    char* getFam() const;
    char* getName() const;
    double getSlr() const;
    bool findByName(const std::string& _fam, const std::string& _name) const;
    friend void findByDep(worker* workers[], int size, int dep);
};

void findByDep(worker* workers[], int size, int dep);

#endif // WORKER_H
